import React, { useState, useEffect } from 'react'
//API Methods
import { Spinner } from '@chakra-ui/react'
import { AddSchoolService } from 'service/addSchoolService'
import { useDispatch, useSelector } from 'react-redux'
import Logo from '../../assets/img/adlogo.png'
import {
    FormControl,
    Select,
    FormErrorMessage
} from '@chakra-ui/react'
import { Button } from 'reactstrap'
import { useNavigate } from 'react-router-dom'

function AddSchool() {
    const navigate=useNavigate()
    const [school, SetSchool] = useState({
        name: "",
        number: "",
        email: "",
        city: "",
        state: "",
        address: "",
        pincode: "",
        website: "",
        password:"",
        landline:""
    })
    const [file, setFile] = useState([])
    const [errors, setErrors] = useState({
        name: "",
        number: "",
        email: "",
        city: "",
        state: "",
        address: "",
        pincode: "",
        website: "",
        file: []
    });

    const loading = useSelector((state) => state?.AddSchoolSlice?.loading)
    const dispatch = useDispatch()

    const handleChange = (e) => {
        const { name, value } = e.target
        SetSchool({
            ...school,
            [name]: value
        })
    }



    const handleFile = (event) => {
        const filelist = event.target.files
        const newFiles = [...file]
        for (let i = 0; i < filelist?.length; i++) {
            const file = filelist[i]
            const filename = file.name
            newFiles.push({ file, filename })
        }
        setFile(newFiles)
    }
    const validateForm = () => {
        const errors = {};
        if (!school.name) {
            errors.name = 'name is required';
        }
        if (!school.number) {
            errors.number = 'number is required';
        }
        if (!school.email) {
            errors.email = 'email is required';
        }
        if (!school.number) {
            errors.number = 'number is required';
        } if (!school.city) {
            errors.city = 'city is required';
        }
        if (!school.state) {
            errors.state = 'state is required';
        } if (!school.address) {
            errors.address = 'address is required';
        }
        if (!school.pincode) {
            errors.pincode = 'pincode is required';
        }
        if (!school.website) {
            errors.website = 'website is required';
        }
        if (!file.length) {
            errors.file = 'File is required';
        }
        return errors;
    };

    const handleClick = async (e) => {
        e.preventDefault();
        try {
            const errors = validateForm();
            setErrors(errors);
            if (Object.keys(errors).length === 0) {
                const data = {
                    file, school
                }
                const response = await dispatch(AddSchoolService(data)).unwrap();
                SetSchool("")
                setFile("")
                navigate('/login')

            } else {
                console.log('Form has errors:', errors);
            }
        } catch (error) {
            console.error('Error while handling form submission:', error);
        }
    };


    return (
        <>
        <style>
            {
                `
                button.btn.btn-secondary:hover {
                    background-color: balck !important;
                    color: white !important;
                }
                .header{
                    display:flex;
                    align-items:center;
                    justify-content:space-between;
                }
                `
            }
        </style>
            <div className="content"  >
            <div className='header' style={{background:'rgba(184, 185, 141, 1)'}}>
                  <div>
                    <img src={Logo}></img>
                  </div>
                  <div>
                    <h3 style={{fontWeight:900,marginTop:'22px'}}>School Form</h3>
                  </div>
                  <div>
                    <h3>.</h3>
                  </div>
            </div>
                {/* <!-- Main Content --> */}
                <div class="col-xs-12 col-lg-12 col-sm-12 col-md-12 mt-4" >
                    <form style={{width:'70%',margin:'auto'}}>
                        <div class="row">
                            <div class="col-lg-4 col-xs-12 col-sm-6">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Name</label>
                                    <FormControl isInvalid={!!errors?.name}>
                                        <input
                                            name="name"
                                            type="email"
                                            class="form-control"
                                            id="exampleInputEmail1"
                                            placeholder="Name"
                                            onChange={handleChange}

                                        />
                                        <FormErrorMessage>{errors.name}</FormErrorMessage>

                                    </FormControl>
                                </div>
                            </div>

                            <div class="col-lg-offset-0 col-lg-4 col-xs-12 col-sm-6">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Contact No.</label>
                                    <FormControl
                                        isInvalid={!!errors?.number}>

                                        <input
                                            name="number"
                                            type="number"
                                            class="form-control"
                                            id="exampleInputEmail1"
                                            placeholder="Mobile No"
                                            onChange={handleChange}


                                        />
                                        <FormErrorMessage>{errors.number}</FormErrorMessage>

                                    </FormControl>

                                </div>
                            </div>

                            <div class="col-lg-offset-0 col-lg-4 col-xs-12 col-sm-6">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Landline  No.</label>
                                        <input
                                            name="landline"
                                            type="number"
                                            class="form-control"
                                            id="exampleInputEmail1"
                                            placeholder="Landline no."
                                            onChange={handleChange}
                                        />


                                </div>
                            </div>

                            <div class="col-lg-offset-0 col-lg-6 col-xs-12 col-sm-6">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Email ID</label>
                                    <FormControl isInvalid={!!errors?.email}>
                                        <input
                                            name="email"
                                            type="email"
                                            class="form-control"
                                            id="exampleInputEmail1"
                                            placeholder="Email ID"
                                            onChange={handleChange}


                                        />
                                        <FormErrorMessage>{errors.email}</FormErrorMessage>

                                    </FormControl>

                                </div>
                            </div>



                          
                            <div class="col-lg-offset-0 col-lg-6 col-xs-12 col-sm-12">
                                <div class="form-group">
                                    <label for="Gender" class="select">State</label>
                                    <FormControl isInvalid={!!errors?.state}>
                                    <Select placeholder='Select State' onChange={handleChange} name="state">

<option value="Andhra Pradesh">Andhra Pradesh</option>
<option value="Arunachal Pradesh">Arunachal Pradesh</option>
<option value="Assam">Assam</option>
<option value="Bihar">Bihar</option>
<option value="Chhattisgarh">Chhattisgarh</option>
<option value="Gujarat">Gujarat</option>
<option value="Haryana">Haryana</option>
<option value="Himachal Pradesh">Himachal Pradesh</option>
<option value="Jammu and Kashmir">Jammu and Kashmir</option>
<option value="Goa">Goa</option>
<option value="Jharkhand">Jharkhand</option>
<option value="Karnataka">Karnataka</option>
<option value="Kerala">Kerala</option>
<option value="Madhya Pradesh">Madhya Pradesh</option>
<option value="Maharashtra">Maharashtra</option>
<option value="Manipur">Manipur</option>
<option value="Meghalaya">Meghalaya</option>
<option value="Mizoram">Mizoram</option>
<option value="Nagaland">Nagaland</option>
<option value="Odisha">Odisha</option>
<option value="Punjab">Punjab</option>
<option value="Rajasthan">Rajasthan</option>
<option value="Sikkim">Sikkim</option>
<option value="Tamil Nadu">Tamil Nadu</option>
<option value="Telangana">Telangana</option>
<option value="Tripura">Tripura</option>
<option value="Uttarakhand">Uttarakhand</option>
<option value="Uttar Pradesh">Uttar Pradesh</option>
<option value="West Bengal">West Bengal</option>
<option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
<option value="Chandigarh">Chandigarh</option>
<option value="Dadra and Nagar Haveli">Dadra and Nagar Haveli</option>
<option value="Daman and Diu">Daman and Diu</option>
<option value="Delhi">Delhi</option>
<option value="Lakshadweep">Lakshadweep</option>
<option value="Puducherry">Puducherry</option>




</Select>
                                        <FormErrorMessage>{errors.state}</FormErrorMessage>

                                    </FormControl>
                                </div>
                            </div>
                            <div class="col-lg-offset-0 col-lg-6 col-xs-12 col-sm-12">
                                <div class="form-group">
                                    <label for="Gender" class="select">City </label>
                                    <FormControl isInvalid={!!errors?.city}>

                                            
                                <Select placeholder='Select City' onChange={handleChange} name="city">
                                    <option value="Noida">Noida</option>
                                    <option value="Greater Noida">Greater Noida</option>
                                    <option value="Mumbai">Mumbai</option>
                                    <option value="Delhi">Delhi</option>
                                    <option value="Bangalore">Bangalore</option>
                                    <option value="Chennai">Chennai</option>
                                    <option value="Kolkata">Kolkata</option>
                                    <option value="Hyderabad">Hyderabad</option>
                                    <option value="Ahmedabad">Ahmedabad</option>
                                    <option value="Pune">Pune</option>
                                    <option value="Jaipur">Jaipur</option>
                                    <option value="Lucknow">Lucknow</option>
                                    <option value="Kanpur">Kanpur</option>
                                    <option value="Patna">Patna</option>
                                    <option value="Bhopal">Bhopal</option>
                                    <option value="Indore">Indore</option>
                                    <option value="Visakhapatnam">Visakhapatnam</option>
                                    <option value="Surat">Surat</option>
                                    <option value="Nagpur">Nagpur</option>
                                    <option value="Varanasi">Varanasi</option>
                                    <option value="Thane">Thane</option>
                                    <option value="Coimbatore">Coimbatore</option>
                                    <option value="Madurai">Madurai</option>
                                    <option value="Agra">Agra</option>
                                    <option value="Kochi">Kochi</option>
                                    <option value="Mysore">Mysore</option>
                                    <option value="Tiruchirappalli">Tiruchirappalli</option>
                                    <option value="Bhubaneswar">Bhubaneswar</option>
                                    <option value="Salem">Salem</option>
                                    <option value="Dehradun">Dehradun</option>
                                    <option value="Faridabad">Faridabad</option>
                                    <option value="Ghaziabad">Ghaziabad</option>
                                    <option value="Gurgaon">Gurgaon</option>
                                    <option value="Allahabad">Allahabad</option>
                                    <option value="Amritsar">Amritsar</option>
                                    <option value="Jodhpur">Jodhpur</option>
                                    <option value="Rajkot">Rajkot</option>
                                    <option value="Srinagar">Srinagar</option>
                                    <option value="Jalandhar">Jalandhar</option>
                                    <option value="Bareilly">Bareilly</option>
                                    <option value="Guwahati">Guwahati</option>
                                    <option value="Vadodara">Vadodara</option>


                                </Select>
                                        <FormErrorMessage>{errors.city}</FormErrorMessage>

                                    </FormControl>

                                </div>
                            </div>
                            <div class="col-lg-offset-0 col-lg-6 col-xs-12 col-sm-12">
                                <div class="form-group">
                                    <label for="Gender" class="select">Address</label>
                                    <FormControl isInvalid={!!errors?.address}>
                                        <input
                                            name="address"
                                            type="text"
                                            class="form-control"
                                            id="exampleInputEmail1"
                                            placeholder="Address"
                                            onChange={handleChange}


                                        />
                                        <FormErrorMessage>{errors.address}</FormErrorMessage>

                                    </FormControl>

                                </div>
                            </div>

                            <div class="col-lg-offset-0 col-lg-6 col-xs-12">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Pincode</label>
                                    <FormControl isInvalid={!!errors?.address}>
                                        <input

                                            name="pincode"
                                            type="text"
                                            class="form-control"
                                            id="exampleInputEmail1"
                                            placeholder="Pincode"
                                            onChange={handleChange}


                                        />
                                        <FormErrorMessage>{errors.pincode}</FormErrorMessage>

                                    </FormControl>

                                </div>
                            </div>
                            <div class="col-lg-offset-0 col-lg-6 col-xs-12">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Website</label>
                                    <FormControl isInvalid={!!errors?.website}>
                                        <input
                                            name="website"
                                            type="text"
                                            class="form-control"
                                            id="exampleInputEmail1"
                                            placeholder="Website"
                                            onChange={handleChange}


                                        />
                                        <FormErrorMessage>{errors.website}</FormErrorMessage>

                                    </FormControl>

                                </div>
                            </div>


                            <div class="col-lg-offset-0 col-lg-6 col-xs-12 col-sm-12">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">School Documents Verification</label>
                                    <FormControl isInvalid={!!errors?.file}>
                                        <input
                                            type="file"
                                            class="form-control"
                                            id="exampleInputEmail1"
                                            placeholder="Upload Aadhar Photo"
                                            onChange={handleFile}

                                        />
                                        <FormErrorMessage>{errors.file}</FormErrorMessage>
                                        
                                        {
                            Array.isArray(file) &&    file?.map((item) => {
                                    return (
                                        <>
                                            <div style={{display:'flex'}}>{item?.filename}</div>
                                        </>
                                    )
                                })
                            }

                                    </FormControl>
                                </div>
                            </div>
                            <div class="col-lg-offset-0 col-lg-6 col-xs-12">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Password</label>
                                    <FormControl >
                                        <input
                                            name="password"
                                            type="text"
                                            class="form-control"
                                            id="exampleInputEmail1"
                                            placeholder="password"
                                            onChange={handleChange}

                                        />

                                    </FormControl>

                                </div>
                            </div>

                        </div>
                        <hr />

                        {/* <!-- /Exit (Are you sure?) Modal --> */}
                        <div class="pull-right">
                            <Button role="button" class="btn btn-primary btn-large" style={{ background: 'rgb(18, 113, 215)', color: 'white', marginTop: '30px' }} onClick={handleClick}>
                                {
                                    loading ? (
                                        <>
                                            <Spinner
                                                thickness='4px'
                                                speed='0.65s'
                                                emptyColor='gray.200'
                                                color='blue.500'
                                                size='sm'
                                            />
                                        </>
                                    ) : 'Submit'
                                }
                            </Button>
                        </div>
                    </form>

                </div>
                {/* <!-- /Main Content -- */}
            </div>
        </>
    )
}
export default AddSchool
