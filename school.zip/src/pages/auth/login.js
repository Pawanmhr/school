import React, { useState } from 'react'
import "../../assets/css/login.css"
import { Link, useNavigate } from "react-router-dom";
import { login } from "../../utils/CheckRoute"
import Logo from '../../assets/img/adlogo.png'
import { LoginService } from 'service/authservice';
import { useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import {
    FormControl,
    FormErrorMessage
} from '@chakra-ui/react'

import { Spinner } from 'reactstrap';


function Login() {
    const dispatch = useDispatch()
    const loading=useSelector((state)=>state?.authslice?.loading)

    const navigate = useNavigate();
    const [login2, setLogin] = useState({
        email: "",
        password: ""
    })
    const [errors, setErrors] = useState({
        email: '',
        password: ''
    });



    const handleChange = (e) => {
        const { name, value } = e.target;
        setLogin((prevLogin) => ({
            ...prevLogin,
            [name]: value
        }));
    };
    const validateForm = () => {
        const errors = {};
        if (!login2.email) {
            errors.email = 'Email is required';
        }
        if (!login2.password) {
            errors.password = 'Password is required';
        }
        return errors;
    };





    const onSubmit = async (e) => {
        e.preventDefault();
        try {
            const errors = validateForm();
            setErrors(errors);
            if (Object.keys(errors).length === 0) {
                const response = await dispatch(LoginService(login2)).unwrap();
                console.log(response)
                localStorage.setItem('schoolId',response?.id)
                localStorage.setItem('schoolname',response?.name)
               login("testToken2")
               navigate("/admin/dashboard");


            } else {
                console.log('Form has errors:', errors);
            }
        } catch (error) {
            console.error('Error while handling form submission:', error);
        }
    };

    // const validate = values => {
    //     const errors = {};
    //     if (!values.username) {
    //       errors.username = 'Username is required';
    //     }
    //     if (!values.password) {
    //       errors.password = 'Password is required';
    //     }
    //     return errors;
    //   };

    // const handleLogin = (e) => {
    //     e.preventDefault()
    //     navigate("/admin/dashboard");
    // }
    return (
        <>
            <style>
                {
                    `
                .screen__content{
                    background:linear-gradient(to right, rgba(228, 229, 166, 1), rgba(184, 185, 141, 1));

                }
                button.button.login__submit{
                    background:linear-gradient(to right, rgba(132, 31, 39, 1),
                    rgba(255, 91, 104, 1));

                }
                
                `
                }
            </style>
            <div class="container" >
                <div class="screen" >
                    <div class="screen__content">
                        <form class="login">
                            <div class="login_logo" style={{ display: 'flex', justifyContent: 'center' }}>
                                <img src={Logo} alt='House Manager Logo' width={150} />
                            </div>
                            <div>
                                <div class="login__field">
                                    <i class="login__icon fas fa-user"></i>
                                    <FormControl isInvalid={!!errors.email}>

                                        <input type="text" class="login__input" name='email' onChange={handleChange} placeholder="Username / Email" />
                                        <FormErrorMessage>{errors.email}</FormErrorMessage>

                                    </FormControl>

                                </div>
                                {errors.email && <span style={{ color: 'red' }}>{errors.email.message}</span>}
                            </div>
                            <div>
                                <div class="login__field" >
                                    <i class="login__icon fas fa-lock"></i>
                                    <FormControl isInvalid={!!errors.password}>
                                        <input type="password" class="login__input" name='password' onChange={handleChange} placeholder="Password" />
                                        <FormErrorMessage>{errors.password}</FormErrorMessage>

                                    </FormControl>
                                </div>
                                <Link to={`/signup`} style={{color:'white',fontWeight:'700'}}>SignUp</Link>
                            </div>
                            <button class="button login__submit" type='submit' onClick={onSubmit}>
                                <span class="button__text" style={{ color: 'white' }}>
                                {
                                            loading?(
                                                <>
                                                 <Spinner
                  thickness='4px'
                  speed='0.65s'
                  emptyColor='gray.200'
                  color='blue.500'
                  size='sm'
                />
                                                </>
                                            ):'Login'
                                        }
                                </span>
                                <i style={{ color: 'white' }} class="button__icon fas fa-chevron-right"></i>
                            </button>
                        </form>
                        <div class="social-login">
                            {/* <h3><a href="kayıtol.php">Kayıt ol</a></h3> */}
                            {/* <h3><a href="sifremiunuttum.php">Şifremi Unuttum</a></h3> */}
                            {/* <div class="social-icons">
                                <a href="https://instagram.com/isikabatay06" class="social-login__icon fab fa-instagram"></a>
                                <a href="#" class="social-login__icon fab fa-facebook"></a>
                                <a href="https://twitter.com/isikabatay06" class="social-login__icon fab fa-twitter"></a>
                            </div> */}
                        </div>
                    </div>

                </div>
            </div>
        </>
    )
}

export default Login