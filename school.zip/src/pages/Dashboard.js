
import React, { useEffect } from "react";
// react plugin used to create charts
import { Line, Pie } from "react-chartjs-2";
// reactstrap components
import pic1 from '../assets/img/dfive.png'
import pic2 from '../assets/img/dfor.png'
import pic3 from '../assets/img/dthre.png'
import pic4 from '../assets/img/dfor.png'
import pic5 from '../assets/img/done.png'
import pic7 from '../assets/img/dtwo.png'

import { DashSchoolService } from "service/schooldashService";



import {
  Card,
  CardHeader,
  CardBody,
  CardFooter,
  CardTitle,
  Row,
  Col,
} from "reactstrap";
// core components
import {
  dashboard24HoursPerformanceChart,
  dashboardEmailStatisticsChart,
  dashboardNASDAQChart,
} from "variables/charts.js";
import { useDispatch, useSelector } from "react-redux";

function Dashboard() {
  const data=useSelector((state)=>state?.SchoolDashSlice?.dash)
  const dispatch=useDispatch()


  useEffect(()=>{
    dispatch(DashSchoolService())
  },[dispatch])




  return (
    <>
      {/* <h1>Dash</h1> */}
      <div className="content">
        <div className="" style={{display:'flex',justifyContent:'end',gap:'3px'}}>
          <h5 style={{fontWeight:'700'}}>
          <i class="fa-solid fa-school" style={{marginRight:'3px',position:'relative',right:'4px'}}></i>
            {localStorage.getItem('schoolname')}</h5>
        </div>
        <Row>
         
          <Col lg="4" md="6" sm="6">
            <Card className="card-stats">
              <CardBody>
              <Row>
                <Col md="6" xs="6">
                    <div className="numbers">
                      <p className="card-category">Total No. of  Students</p>
                      <p />
                    </div>
                  </Col>
                  <Col md="4" xs="5" style={{height:"100px"}}>
                    <div className="icon-big text-center icon-warning">
                      <img src={pic2}/>
                    </div>
                  </Col>
                  <Col md="6" xs="6">
                    <div className="numbers">
                      <CardTitle className="num" tag="p">{data?.totalNumberOFStudent}{data?.totalNumberOFStudent===""?'+':""}</CardTitle>
                      <p />
                    </div>
                  </Col>
                </Row>
              </CardBody>
              <CardFooter>
                <hr />
                <div className="stats">
                  <i className="far fa-calendar" /> Last day
                </div>
              </CardFooter>
            </Card>
          </Col>
          <Col lg="4" md="6" sm="6">
            <Card className="card-stats">
              <CardBody>
              <Row>
                <Col md="6" xs="6">
                    <div className="numbers">
                      <p className="card-category">Scholarship Allotted
to Students</p>
                      <p />
                    </div>
                  </Col>
                  <Col md="4" xs="5" style={{height:"100px"}}>
                    <div className="icon-big text-center icon-warning">
                      <img src={pic3}/>
                    </div>
                  </Col>
                  <Col md="6" xs="6">
                    <div className="numbers">
                      <CardTitle className="num" tag="p"> {data?.totalAllotedScholarShipToStudents===""?'₹':""}   {data?.totalAllotedScholarShipToStudents} </CardTitle>
                      <p />
                    </div>
                  </Col>
                </Row>
              </CardBody>
              <CardFooter>
                <hr />
                <div className="stats">
                  <i className="fas fa-sync-alt" /> Update now
                </div>
              </CardFooter>
            </Card>
          </Col>
    
        </Row>
      
      </div>
    </>
  );
}

export default Dashboard;
