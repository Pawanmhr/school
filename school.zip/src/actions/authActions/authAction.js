export const setAuthenticated = (token) => ({
    type: 'SET_AUTHENTICATED',
    payload: token,
});
export const clearAuthentication = () => ({
    type: 'CLEAR_AUTHENTICATION',
});