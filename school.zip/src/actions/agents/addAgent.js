import {
    POST_AGENT_REQUEST,
    POST_AGENT_SUCCESS,
    POST_AGENT_FAILURE,
} from "../type";
import axios from "axios";

export const addAgentRequest = () => {
    return {
        type: POST_AGENT_REQUEST,
    };
};
export const addAgentSuccess = (Data) => {
    return {
        type: POST_AGENT_SUCCESS,
        payload: { data: Data, message: Data },
    };
};

export const addAgentFailure = (Error) => {
    return {
        type: POST_AGENT_FAILURE,
        payload: Error,
    };
};
export const addAgent = (data) => {
    console.log("add Function Called")
    // const headers = {
    //     "Content-Type": "application/json",
    //     // 'Authorization': basicAuth,
    // };
    // return (dispatch) => {
    //     dispatch(addAgentRequest());
    //     axios
    //         .post(baseUrl + `addAgent`, {
    //             "recordDate": today,
    //             "recordTime": bookingSlot,
    //             "patient": {
    //                 "patientId": patientId
    //             }
    //         }, {
    //             headers: headers,
    //         })
    //         .then(async function (response) {

    //             localStorage.setItem("message", "addAgentSuccess")
    //             await dispatch(addAgentSuccess(response.data));

    //             // window.reload()
    //         })
    //         .catch(function (error) {

    //             localStorage.setItem("message", "addAgentFailed")
    //             dispatch(addAgentFailure(error));
    //         });
    // };
};
