import {
    UPDATE_AGENT_REQUEST,
    UPDATE_AGENT_SUCCESS,
    UPDATE_AGENT_FAILURE,
} from "../type";
import axios from "axios";

export const updateAgentRequest = () => {
    return {
        type: UPDATE_AGENT_REQUEST,
    };
};
export const updateAgentSuccess = (Data) => {
    return {
        type: UPDATE_AGENT_SUCCESS,
        payload: { data: Data, message: Data },
    };
};

export const updateAgentFailure = (Error) => {
    return {
        type: UPDATE_AGENT_FAILURE,
        payload: Error,
    };
};
export const updateAgent = (data) => {
    console.log("add Function Called")
    // const headers = {
    //     "Content-Type": "application/json",
    //     // 'Authorization': basicAuth,
    // };
    // return (dispatch) => {
    //     dispatch(updateAgentRequest());
    //     axios
    //         .post(baseUrl + `updateAgent`, {
    //             "recordDate": today,
    //             "recordTime": bookingSlot,
    //             "patient": {
    //                 "patientId": patientId
    //             }
    //         }, {
    //             headers: headers,
    //         })
    //         .then(async function (response) {

    //             localStorage.setItem("message", "updateAgentSuccess")
    //             await dispatch(updateAgentSuccess(response.data));

    //             // window.reload()
    //         })
    //         .catch(function (error) {

    //             localStorage.setItem("message", "updateAgentFailed")
    //             dispatch(updateAgentFailure(error));
    //         });
    // };
};
