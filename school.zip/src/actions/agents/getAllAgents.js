import {
    GET_ALL_AGENT_REQUEST,
    GET_ALL_AGENT_SUCCESS,
    GET_ALL_AGENT_FAILURE,
} from "../type";
import axios from "axios";

export const fetchAllAgentsRequest = () => {
    return {
        type: GET_ALL_AGENT_REQUEST,
    };
};
export const fetchAllAgentsSuccess = (Data) => {
    return {
        type: GET_ALL_AGENT_SUCCESS,
        payload: Data,
    };
};

export const fetchAllAgentsFailure = (Error) => {
    return {
        type: GET_ALL_AGENT_FAILURE,
        payload: Error,
    };
};

export const fetchAllAgents = () => {
    // var patientId = localStorage.getItem("patientId")
    // const headers = {
    //     "Content-Type": "application/x-www-form-urlencoded;  charset=UTF-8",
    //     // 'Authorization': basicAuth,
    // };
    // return (dispatch) => {
    //     dispatch(fetchAllAgentsRequest);
    //     axios
    //         .get(baseUrl + `getAllAppointmentsByPatientId/${patientId}`, {
    //             headers: headers,
    //         })
    //         .then(function (response) {
    //             const dataArray = []
    //             for (var i = 0; i < response.data.length; i++) {
    //                 if (response.data[i].prescriptionOneToOne == null) {
    //                     dataArray.push(response.data[i])
    //                 }
    //             }
    //             localStorage.setItem("message", "fetchAllAgentsuccuss")
    //             dispatch(fetchAllAgentsSuccess(dataArray));
    //         })
    //         .catch(function (error) {
    //             localStorage.setItem("message", "fetchAllAgentsFailed")

    //             dispatch(fetchAllAgentsFailure(error));
    //         });
    // };
};


