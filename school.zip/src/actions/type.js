
// ------------------------------------------------------Agent-----------------------------------------------------
//Add Agent
export const POST_AGENT_REQUEST = "POST_AGENT_REQUEST";
export const POST_AGENT_SUCCESS = "POST_AGENT_SUCCESS";
export const POST_AGENT_FAILURE = "POST_AGENT_FAILURE";
// Update Agent
export const UPDATE_AGENT_REQUEST = "UPDATE_AGENT_REQUEST";
export const UPDATE_AGENT_SUCCESS = "UPDATE_AGENT_SUCCESS";
export const UPDATE_AGENT_FAILURE = "UPDATE_AGENT_FAILURE";
// Delete Agent
export const DELETE_AGENT_REQUEST = "DELETE_AGENT_REQUEST";
export const DELETE_AGENT_SUCCESS = "DELETE_AGENT_SUCCESS";
export const DELETE_AGENT_FAILURE = "DELETE_AGENT_FAILURE";
//Get Agent By Id
export const GET_AGENT_BY_ID_REQUEST = "GET_AGENT_BY_ID_REQUEST";
export const GET_AGENT_BY_ID_SUCCESS = "GET_AGENT_BY_ID_SUCCESS";
export const GET_AGENT_BY_ID_FAILURE = "GET_AGENT_BY_ID_FAILURE";
// Get All Agent
export const GET_ALL_AGENT_REQUEST = "GET_ALL_AGENT_REQUEST";
export const GET_ALL_AGENT_SUCCESS = "GET_ALL_AGENT_SUCCESS";
export const GET_ALL_AGENT_FAILURE = "GET_ALL_AGENT_FAILURE";