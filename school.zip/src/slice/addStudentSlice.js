import { createSlice } from "@reduxjs/toolkit";
import { sucessToast } from "../toast/toast";
import { AddStudentService } from "service/addStudentService";
const initialState = {
  data: null,
  loading: false,
  error: null,
  classNotesList: [],
};


const AddStudentSlice = createSlice({
  name: "AddStudentSlice",
  initialState,
  extraReducers: (builder) => {
    builder.addCase(AddStudentService.pending, (state) => {
      return { ...state, loading: true };
    });
    builder.addCase(AddStudentService.fulfilled, (state, action) => {
      sucessToast("Student Added Sucessfully");
      return { ...state,  loading: false };
    });
    builder.addCase(AddStudentService.rejected, (state, action) => {
      return { ...state, loading: false, error: "Something went wrong" };
    });

    
  },
});


export default AddStudentSlice.reducer;

