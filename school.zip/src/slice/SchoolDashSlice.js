import { createSlice } from "@reduxjs/toolkit";
import { sucessToast } from "../toast/toast";

import { DashSchoolService } from "service/schooldashService";

const initialState = {
  dash: null,
  loading: false,
  error: null,
  classNotesList: [],
};

const DashBoardSlice = createSlice({
  name: "DashBoardSlice",
  initialState,
  extraReducers: (builder) => {
    builder.addCase(DashSchoolService.pending, (state) => {
      return { ...state, loading: true };
    });
    builder.addCase(DashSchoolService.fulfilled, (state, action) => {
      return { ...state,  loading: false ,dash:action?.payload};
    });
    builder.addCase(DashSchoolService.rejected, (state, action) => {
      return { ...state, loading: false, error: "Something went wrong" };
    });

    
  },
});


export default DashBoardSlice.reducer;

