import { createSlice } from "@reduxjs/toolkit";
import { sucessToast } from "../toast/toast";
import { GetBugetDashboardService } from "service/GetBudgetDashBoardService";
const initialState = {
  DASH: [],
  loading: false,
  error: null,
};

const GetBudgetDashBoardSLICE = createSlice({
  name: "GetBudgetDashBoardSLICE",
  initialState,
  extraReducers: (builder) => {
    builder.addCase(GetBugetDashboardService.pending, (state) => {
      return { ...state, loading: true };
    });
    builder.addCase(GetBugetDashboardService.fulfilled, (state, action) => {
      return { ...state,  loading: false,DASH:action.payload };
    });
    builder.addCase(GetBugetDashboardService.rejected, (state, action) => {
      return { ...state, loading: false, error: "Something went wrong" };
    });
  },
});


export default GetBudgetDashBoardSLICE.reducer;

