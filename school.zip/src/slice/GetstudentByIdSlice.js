import { createSlice } from "@reduxjs/toolkit";
import { sucessToast } from "../toast/toast";
import { GetStudentByIdService } from "service/getStudentByIdService";
const initialState = {
  school: [],
  loading: false,
  error: null,
};

const GetStudentByIdSlice = createSlice({
  name: "GetStudentByIdSlice",
  initialState,
  extraReducers: (builder) => {
    builder.addCase(GetStudentByIdService.pending, (state) => {
      return { ...state, loading: true };
    });
    builder.addCase(GetStudentByIdService.fulfilled, (state, action) => {
      return { ...state,  loading: false,school:action.payload };
    });
    builder.addCase(GetStudentByIdService.rejected, (state, action) => {
      return { ...state, loading: false, error: "Something went wrong" };
    });
  },
});


export default GetStudentByIdSlice.reducer;

