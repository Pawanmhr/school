import { createSlice } from "@reduxjs/toolkit";
import { sucessToast } from "../toast/toast";
import { GetApprovedSchoolService } from "service/getApproveSchoolService";
const initialState = {
  admin: [],
  loading: false,
  error: null,
};

const GetApproveSchoolSlice = createSlice({
  name: "GetApproveSchoolSlice",
  initialState,
  extraReducers: (builder) => {
    builder.addCase(GetApprovedSchoolService.pending, (state) => {
      return { ...state, loading: true };
    });
    builder.addCase(GetApprovedSchoolService.fulfilled, (state, action) => {
      return { ...state,  loading: false,admin:action.payload };
    });
    builder.addCase(GetApprovedSchoolService.rejected, (state, action) => {
      return { ...state, loading: false, error: "Something went wrong" };
    });
  },
});


export default GetApproveSchoolSlice.reducer;

