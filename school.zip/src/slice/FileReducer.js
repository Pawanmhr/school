import { createSlice } from "@reduxjs/toolkit";
import { sucessToast } from "../toast/toast";
import { FileService } from "service/fileService";
const initialState = {
  file: null,
  loading: false,
  error: null,
  classNotesList: [],
};

const FileSlice = createSlice({
  name: "FileSlice",
  initialState,
  extraReducers: (builder) => {
    builder.addCase(FileService.pending, (state) => {
      return { ...state, loading: true };
    });
    builder.addCase(FileService.fulfilled, (state, action) => {
      return { ...state,  loading: false,file:action.payload };
    });
    builder.addCase(FileService.rejected, (state, action) => {
      return { ...state, loading: false, error: "Something went wrong" };
    });

    
  },
});


export default FileSlice.reducer;

