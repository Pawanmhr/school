import { createSlice } from "@reduxjs/toolkit";
import { sucessToast } from "../toast/toast";
import { GetScholsarshipService } from "service/GetSchlorashipService";
const initialState = {
  scholar: [],
  loading: false,
  error: null,
};

const GetSchloarShipSlice = createSlice({
  name: "GetSchloarShipSlice",
  initialState,
  extraReducers: (builder) => {
    builder.addCase(GetScholsarshipService.pending, (state) => {
      return { ...state, loading: true };
    });
    builder.addCase(GetScholsarshipService.fulfilled, (state, action) => {
      return { ...state,  loading: false,scholar:action.payload };
    });
    builder.addCase(GetScholsarshipService.rejected, (state, action) => {
      return { ...state, loading: false, error: "Something went wrong" };
    });
  },
});


export default GetSchloarShipSlice.reducer;

