import { createSlice } from "@reduxjs/toolkit";
import { sucessToast } from "../toast/toast";
import { AddSchoolService } from "service/addSchoolService";

const initialState = {
  data: null,
  loading: false,
  error: null,
  classNotesList: [],
};

const AddSchoolSlice = createSlice({
  name: "AddSchoolSlice",
  initialState,
  extraReducers: (builder) => {
    builder.addCase(AddSchoolService.pending, (state) => {
      return { ...state, loading: true };
    });
    builder.addCase(AddSchoolService.fulfilled, (state, action) => {
      sucessToast("School Added Sucessfully");
      return { ...state,  loading: false };
    });
    builder.addCase(AddSchoolService.rejected, (state, action) => {
      return { ...state, loading: false, error: "Something went wrong" };
    });

    
  },
});


export default AddSchoolSlice.reducer;

