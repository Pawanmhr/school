import { createSlice } from "@reduxjs/toolkit";
import { sucessToast } from "../toast/toast";
import { StatusApprovedService } from "service/statusApprovedStudentService";

const initialState = {
  data: null,
  loading: false,
  error: null,
  classNotesList: [],
};

const StatusApprovedSlice = createSlice({
  name: "StatusApprovedSlice",
  initialState,
  extraReducers: (builder) => {
    builder.addCase(StatusApprovedService.pending, (state) => {
      return { ...state, loading: true };
    });
    builder.addCase(StatusApprovedService.fulfilled, (state, action) => {
      sucessToast("Status  Approved Sucessfully");
      return { ...state,  loading: false };
    });
    builder.addCase(StatusApprovedService.rejected, (state, action) => {
      return { ...state, loading: false, error: "Something went wrong" };
    });

    
  },
});


export default StatusApprovedSlice.reducer;

