import { createSlice } from "@reduxjs/toolkit";
import { sucessToast } from "../toast/toast";
import { GetApprovedSchoolService } from "service/approvedStudentService";
const initialState = {
  student: [],
  loading: false,
  error: null,
};

const GetApprovedSTUDENTSLICE = createSlice({
  name: "GetApprovedSTUDENTSLICE",
  initialState,
  extraReducers: (builder) => {
    builder.addCase(GetApprovedSchoolService.pending, (state) => {
      return { ...state, loading: true };
    });
    builder.addCase(GetApprovedSchoolService.fulfilled, (state, action) => {
      return { ...state,  loading: false,student:action.payload };
    });
    builder.addCase(GetApprovedSchoolService.rejected, (state, action) => {
      return { ...state, loading: false, error: "Something went wrong" };
    });
  },
});


export default GetApprovedSTUDENTSLICE.reducer;

