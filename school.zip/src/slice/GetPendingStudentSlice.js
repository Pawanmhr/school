import { createSlice } from "@reduxjs/toolkit";
import { sucessToast } from "../toast/toast";
import { GetPendingStudentService } from "service/PendingStudentService";
const initialState = {
  pending: [],
  loading: false,
  error: null,
};

const GetPendingStudentSlice = createSlice({
  name: "GetPendingStudentSlice",
  initialState,
  extraReducers: (builder) => {
    builder.addCase(GetPendingStudentService.pending, (state) => {
      return { ...state, loading: true };
    });
    builder.addCase(GetPendingStudentService.fulfilled, (state, action) => {
      return { ...state,  loading: false,pending:action.payload };
    });
    builder.addCase(GetPendingStudentService.rejected, (state, action) => {
      return { ...state, loading: false, error: "Something went wrong" };
    });
  },
});


export default GetPendingStudentSlice.reducer;

