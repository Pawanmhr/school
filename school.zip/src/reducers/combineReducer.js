import { combineReducers } from "redux";
import authslice from "slice/authslice";
import SchoolDashSlice from "slice/SchoolDashSlice";
import addStudentSlice from "slice/addStudentSlice";
import GetApprovedStudentSlice from "slice/GetApprovedStudentSlice";
import GetPendingStudentSlice from "slice/GetPendingStudentSlice";
import GetScholarShipSlice from "slice/GetScholarShipSlice";
import GetDashBoardBugetSlice from "slice/GetDashBoardBugetSlice";
import AddSchoolSlice from "slice/AddSchoolSlice";
import getApprovedSchoolSlice from "slice/getApprovedSchoolSlice";
import UpdateStudentSlice from "slice/UpdateStudentSlice";
import GetstudentByIdSlice from "slice/GetstudentByIdSlice";
import FileReducer from "slice/FileReducer";

export const rootReducer = combineReducers({
    authslice, SchoolDashSlice,
    addStudentSlice,
    GetApprovedStudentSlice,
    GetPendingStudentSlice, GetScholarShipSlice,
    GetDashBoardBugetSlice,
    AddSchoolSlice,
    UpdateStudentSlice,
    getApprovedSchoolSlice,
    GetstudentByIdSlice,
    FileReducer
})