// authReducer.js
const initialState = {
    isAuthenticated: false,
    token: null,
};

const authReducer = (state = initialState, action) => {
    switch (action.type) {
        case 'SET_AUTHENTICATED':
            return {
                isAuthenticated: true,
                token: action.payload,
            };
        case 'CLEAR_AUTHENTICATION':
            return initialState;
        default:
            return state;
    }
};

export default authReducer;
