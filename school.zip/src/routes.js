import Pending from "components/school/pending";
import Dashboard from "pages/Dashboard.js";
import AddSchool from "components/school/addSchool";
import Approved from "components/school/approved";
import Students from "components/school/students";
import AddStudent from "components/school/addStudent";
import AllAdmin from "components/school/admin";
import Budget from "components/school/buget";
import CreateAdmin from "components/school/createAdmin";
import Scholarship from "components/school/scholarShip";
import TotalBudgetHistory from "components/school/totalBudgetHistory";
import ALLOTEDbUDGEThISTORY from "components/school/alotedbudgethistory";
import AllotedBudgetStudent from "components/school/allotedBudgetStudent";
var routes = [
  //Dashboard route
  {
    path: "/AddStudent",
    name: "AddStudent",
    icon: "nc-icon nc-bank",
    component: <AddStudent/>,
    layout: "/admin",
    showInSidebar: false,
  },
 
 
 
  {
    path: "/dashboard",
    name: "Dashboard",
    icon: "nc-icon nc-bank",
    component: <Dashboard/>,
    layout: "/admin",
    showInSidebar: true,
  },
  // End of dashboard route
  // School Route
 
  //End of School Route
  //Delivery Agent 
 
 
 
  






  // {
  //   path: "/all-others-images",
  //   name: "Students",
  //   icon: "far fa-clipboard",
  //   component: <OtherImages />,
  //   layout: "/admin",
  //   showInSidebar: false,
  // },
  // {
  //   path: "/add-others-images",
  //   name: "All Others",
  //   icon: "far fa-clipboard",
  //   component: <AddOtherImages />,
  //   layout: "/admin",
  //   showInSidebar: false,
  // },
  // {
  //   path: "/update-others-images",
  //   name: "All Others",
  //   icon: "far fa-clipboard",
  //   component: <UpdateOtherImages />,
  //   layout: "/admin",
  //   showInSidebar: false,
  // },
  // {
  //   path: "/pages-details",
  //   name: "Pages Details",
  //   icon: "far fa-clipboard",
  //   component: <PagesDetails />,
  //   layout: "/admin",
  //   showInSidebar: false,
  // },
  // {
  //   path: "/add-new-pages",
  //   name: "Pages Details",
  //   icon: "far fa-clipboard",
  //   component: <AddNewPage />,
  //   layout: "/admin",
  //   showInSidebar: false,
  // },
  // {
  //   path: "/update-page",
  //   name: "Pages Details",
  //   icon: "far fa-clipboard",
  //   component: <UpdateNewPage />,
  //   layout: "/admin",
  //   showInSidebar: false,
  // },

  // {
  //   path: "/products",
  //   name: "All Others",
  //   icon: "fab fa-audible",
  //   layout: "/admin",
  //   showInSidebar: true,
  //   submenu: [
  //     {
  //       path: "/all-others-images",
  //       name: "Others Images",
  //       showInSidebar: true,
  //     },
  //     {
  //       path: "/pages-details",
  //       name: "Pages Details",
  //       showInSidebar: true,
  //     },
  //   ],
  // },
  // //End Of Others Images 
  // //Order Details
  // {
  //   path: "/view-order",
  //   name: "Students",
  //   icon: "far fa-clipboard",
  //   component: <ViewOrder />,
  //   layout: "/admin",
  //   showInSidebar: false,
  // },
  // {
  //   path: "/view-order-details",
  //   name: "Pending",
  //   icon: "far fa-clipboard",
  //   component: <ViewOrderDetails />,
  //   layout: "/admin",
  //   showInSidebar: false,
  // },
  // {
  //   path: "/update-order-details",
  //   name: "Order Details",
  //   icon: "far fa-clipboard",
  //   component: <UpdateOrderDetails />,
  //   layout: "/admin",
  //   showInSidebar: false,
  // },
  // {
  //   path: "/all-cancel-orders",
  //   name: "Cancel Order",
  //   icon: "far fa-clipboard",
  //   component: <CancelOrder />,
  //   layout: "/admin",
  //   showInSidebar: false,
  // },
  // {
  //   path: "/view-cancel-order",
  //   name: "Cancel Order",
  //   icon: "far fa-clipboard",
  //   component: <ViewCancelOrderDetails />,
  //   layout: "/admin",
  //   showInSidebar: false,
  // },
  // {
  //   path: "/update-cancel-order",
  //   name: "Cancel Order",
  //   icon: "far fa-clipboard",
  //   component: <UpdateCancelOrder />,
  //   layout: "/admin",
  //   showInSidebar: false,
  // },
  // {
  //   path: "/hold-orders",
  //   name: "Hold Order",
  //   icon: "far fa-clipboard",
  //   component: <HoldOrder />,
  //   layout: "/admin",
  //   showInSidebar: false,
  // },
  // {
  //   path: "/orders-reciepts",
  //   name: "Order Reciepts",
  //   icon: "far fa-clipboard",
  //   component: <OrderReciepts />,
  //   layout: "/admin",
  //   showInSidebar: false,
  // },
  // {
  //   path: "/all-close-orders",
  //   name: "Close Order",
  //   icon: "far fa-clipboard",
  //   component: <CloseOrder />,
  //   layout: "/admin",
  //   showInSidebar: false,
  // },


  // //End Of Order Details

  // //Inventry

  // {
  //   path: "/all-venders",
  //   name: "Venders",
  //   icon: "far fa-clipboard",
  //   component: <Vender />,
  //   layout: "/admin",
  //   showInSidebar: false,
  // },
  // {
  //   path: "/add-vender",
  //   name: "Venders",
  //   icon: "far fa-clipboard",
  //   component: <AddVender />,
  //   layout: "/admin",
  //   showInSidebar: false,
  // },
  // {
  //   path: "/update-vender",
  //   name: "Venders",
  //   icon: "far fa-clipboard",
  //   component: <UpdateVender />,
  //   layout: "/admin",
  //   showInSidebar: false,
  // },
  // {
  //   path: "/channel-partner",
  //   name: "Chennel Partner",
  //   icon: "far fa-clipboard",
  //   component: <ChannelPartner />,
  //   layout: "/admin",
  //   showInSidebar: false,
  // },
  // {
  //   path: "/add-channel-partner",
  //   name: "Chennel Partner",
  //   icon: "far fa-clipboard",
  //   component: <AddChannelPartner />,
  //   layout: "/admin",
  //   showInSidebar: false,
  // },
  // {
  //   path: "/update-channel-partner",
  //   name: "Chennel Partner",
  //   icon: "far fa-clipboard",
  //   component: <UpdateChannelPartner />,
  //   layout: "/admin",
  //   showInSidebar: false,
  // },
  // {
  //   path: "/all-available-inventry",
  //   name: "Available Inventry",
  //   icon: "far fa-clipboard",
  //   component: <AvailabeInventry />,
  //   layout: "/admin",
  //   showInSidebar: false,
  // },
  // {
  //   path: "/total-inventry",
  //   name: "Total Inventry",
  //   icon: "far fa-clipboard",
  //   component: <TotalInventry />,
  //   layout: "/admin",
  //   showInSidebar: false,
  // },
  // {
  //   path: "/add-new-inventry",
  //   name: "Total Inventry",
  //   icon: "far fa-clipboard",
  //   component: <AddInventry />,
  //   layout: "/admin",
  //   showInSidebar: false,
  // },
  // {
  //   path: "/update-inventry",
  //   name: "Total Inventry",
  //   icon: "far fa-clipboard",
  //   component: <UpdateInventry />,
  //   layout: "/admin",
  //   showInSidebar: false,
  // },
  // {
  //   path: "/comming-inventry",
  //   name: "Comming Inventry",
  //   icon: "far fa-clipboard",
  //   component: <CommingInventry />,
  //   layout: "/admin",
  //   showInSidebar: false,
  // },

  // {
  //   path: "/products",
  //   name: "Inventry",
  //   icon: "fas fa-shopping-basket",
  //   layout: "/admin",
  //   showInSidebar: true,
  //   submenu: [
  //     {
  //       path: "/all-venders",
  //       name: "Venders",
  //       showInSidebar: true,
  //     },
  //     {
  //       path: "/channel-partner",
  //       name: "Chennel Partner",
  //       showInSidebar: true,
  //     },
  //     {
  //       path: "/all-available-inventry",
  //       name: "Available Inventry",
  //       showInSidebar: true,
  //     },
  //     {
  //       path: "/total-inventry",
  //       name: "Total Inventry",
  //       showInSidebar: true,
  //     },
  //     {
  //       path: "/comming-inventry",
  //       name: "Comming Inventry",
  //       showInSidebar: true,
  //     },
  //   ],
  // },
  // //End Of Inventry
  // //City 

  // {
  //   path: "/city",
  //   name: "City",
  //   icon: "far fa-clipboard",
  //   component: <City />,
  //   layout: "/admin",
  //   showInSidebar: false,
  // },
  // {
  //   path: "/add-city",
  //   name: "City",
  //   icon: "far fa-clipboard",
  //   component: <AddCity />,
  //   layout: "/admin",
  //   showInSidebar: false,
  // },
  // {
  //   path: "/update-city",
  //   name: "City",
  //   icon: "far fa-clipboard",
  //   component: <UpdateCity />,
  //   layout: "/admin",
  //   showInSidebar: false,
  // },
  // {
  //   path: "/pin-code",
  //   name: "PinCode",
  //   icon: "far fa-clipboard",
  //   component: <Pincode />,
  //   layout: "/admin",
  //   showInSidebar: false,
  // },

  // {
  //   path: "/add-pin-code",
  //   name: "City",
  //   icon: "far fa-clipboard",
  //   component: <AddPinCode />,
  //   layout: "/admin",
  //   showInSidebar: false,
  // },

  // {
  //   path: "/city",
  //   name: "City",
  //   icon: "fas fa-city",
  //   layout: "/admin",
  //   showInSidebar: true,
  //   submenu: [
  //     {
  //       path: "/city",
  //       name: "City",
  //       showInSidebar: true,
  //     },
  //     {
  //       path: "/pin-code",
  //       name: "PinCode",
  //       showInSidebar: true,
  //     },
  //   ],
  // },
  // //End of city

  // //Reminder
  // // 
  // {
  //   path: "/reminder-orders",
  //   name: "Reminder Order",
  //   icon: "far fa-clipboard",
  //   component: <ReminderOrder />,
  //   layout: "/admin",
  //   showInSidebar: false,
  // },
  // {
  //   path: "/emi-collections",
  //   name: "Collection EMI",
  //   icon: "far fa-clipboard",
  //   component: <EmiCollection />,
  //   layout: "/admin",
  //   showInSidebar: false,
  // },


  // {
  //   path: "/products",
  //   name: "Reminder Order",
  //   icon: "fas fa-mail-bulk",
  //   layout: "/admin",
  //   showInSidebar: true,
  //   submenu: [
  //     {
  //       path: "/reminder-orders",
  //       name: "Reminder Order",
  //       showInSidebar: true,

  //     },
  //     {
  //       path: "/emi-collections",
  //       name: "Collection EMI",
  //       showInSidebar: true,
  //     },
  //   ],
  // },
  {
    path: "/Pending",
    name: "Pending",
    icon: "fas fa-rupee-sign",
    component: <Pending />,
    layout: "/admin",
    showInSidebar: false
  },
  {
    path: "/Approved",
    icon: "fas fa-rupee-sign",

    component: <Approved />,
    name: "Approved",
    layout: "/admin",

    showInSidebar: false,
  },
  {
    path: "/Allotted-Budget-History",
    name: "Allotted Budget History",
    component:<ALLOTEDbUDGEThISTORY/>,
    layout: "/admin",
    showInSidebar: false,
  },
  
  {
    path: "/Scholarship",
    name: "Grants",
    icon: "fas fa-rupee-sign",
    layout: "/admin",
    component:<Scholarship/>,
    showInSidebar: false,
  },
   
  {
    path: "/Allotted-Budget-Student",
    name: "Allotted Budget Student",
    layout: "/admin",
    component:<AllotedBudgetStudent/>,
    
    showInSidebar: false,
  },
  {
    path: "/students",
    name: "Student",
    component: <Students />,
    icon: "fas fa-user-tie",
    layout: "/admin",
    showInSidebar: true,
    submenu: [
      {
        path: "/Pending",
        name: "Pending",
        icon: "fas fa-rupee-sign",
        component: <Pending />,
        layout: "/admin",
        showInSidebar: true,
      },
      
      {
        path: "/Approved",
        icon: "fas fa-rupee-sign",

        component: <Approved />,
        name: "Approved",
        layout: "/admin",

        showInSidebar: true,
      },
      ,
      
      {
        path: "/Scholarship",
        name: "Grants",
        icon: "fas fa-rupee-sign",
        layout: "/admin",
        component:<Scholarship/>,
        showInSidebar: true,
      }

    ],
  },
  {
    path: "/Total-Budget-History",
    name: "Total Budget History",
    icon: "fas fa-rupee-sign",
    component: <TotalBudgetHistory />,
    layout: "/admin",
    showInSidebar: false,
  },
  {
    path: "/Budget",
    name: "Budget",
    component: <Budget />,
    icon: "fas fa-rupee-sign",
    layout: "/admin",
    showInSidebar: true,
    submenu: [
      {
        path: "/Allotted-Budget-Student",
        name: "Allotted Budget Student",
        component:<AllotedBudgetStudent/>,
        
        showInSidebar: true,
      }

    ],
  },


  



];
export default routes;
