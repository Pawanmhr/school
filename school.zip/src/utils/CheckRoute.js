// AuthService.js
const TOKEN_KEY = 'user_token';

const clearLocalStorage = () => {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.clear()
};

// Check if the token has expired and clear local storage
const checkLocalStorageTimer = () => {
    const token = localStorage.getItem(TOKEN_KEY);
    if (token) {
        const clearLocalStorageTimer = localStorage.getItem('clearLocalStorageTimer');
        if (clearLocalStorageTimer) {
            const timerEnd = parseInt(clearLocalStorageTimer, 10);
            const currentTime = Date.now();
            if (currentTime >= timerEnd) {
                clearLocalStorage();
                localStorage.removeItem('clearLocalStorageTimer');
            }
        }
    }
};
setInterval(checkLocalStorageTimer, 1000);

export const login = (token) => {
    localStorage.setItem(TOKEN_KEY, token);

    // Set a timer to clear the token after 8 Hours (for testing)
    const clearLocalStorageTimer = Date.now() + 8 * 60 * 60 * 1000 // 8 hours in milliseconds 
    localStorage.setItem('clearLocalStorageTimer', clearLocalStorageTimer.toString());

};

export const logout = () => {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.clear()
    // // Clear the timer for clearing local storage
    // const clearLocalStorageTimer = localStorage.getItem('clearLocalStorageTimer');
    // if (clearLocalStorageTimer) {
    //     clearTimeout(parseInt(clearLocalStorageTimer, 10));
    //     localStorage.removeItem('clearLocalStorageTimer');
    // }
};

export const isAuthenticated = () => {
    return localStorage.getItem(TOKEN_KEY) !== null;
};
