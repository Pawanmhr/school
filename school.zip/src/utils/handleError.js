import { toast } from "react-toastify";

export const handleError = (err) => {
  if (err.response && err.response.data) {
    
      toast.error(err.response.data);
  } else {
    toast.error('Something went wrong');
  }
};
