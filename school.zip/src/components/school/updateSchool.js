import { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';

function UpdateSchool() {
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  return (
    <>
    <style>
      {
        `
        .modal-dialog {
          max-width: 58%;
          margin: 1.75rem auto;
      }
        `
      }
    </style>
      <Button variant="blue" style={{background:'rgb(18, 113, 215)',color:'white',marginTop:'30px'}} onClick={handleShow}>
       
      <i className="fa fa-pencil-square-o">
                                </i>  Edit
      </Button>

      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
        </Modal.Header>
        <Modal.Body>
        <div className="content">
                {/* <!-- Main Content --> */}
                <div class="col-xs-12 col-lg-12 col-sm-12 col-md-12 mt-4" >
                    <form>
                        <div class="row">
                            <div class="col-lg-6 col-xs-12 col-sm-6">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Name</label>
                                    <input
                                        type="email"
                                        class="form-control"
                                        id="exampleInputEmail1"
                                        placeholder="Name"
                                      
                                    />
                                   
                                </div>
                            </div>

                            <div class="col-lg-offset-0 col-lg-6 col-xs-12 col-sm-6">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Contact No.</label>
                                    <input
                                        type="email"
                                        class="form-control"
                                        id="exampleInputEmail1"
                                        placeholder="Mobile No"
                                       
                                    />
                                   
                                </div>
                            </div>

                            <div class="col-lg-offset-0 col-lg-6 col-xs-12 col-sm-6">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Email ID</label>
                                    <input
                                        type="email"
                                        class="form-control"
                                        id="exampleInputEmail1"
                                        placeholder="Email ID"
                                       
                                    />
                                   
                                </div>
                            </div>



                            <div class="col-lg-offset-0 col-lg-6 col-xs-12 col-sm-12">
                                <div class="form-group">
                                    <label for="Gender" class="select">City </label>
                                    <input
                                        type="text"
                                        class="form-control"
                                        id="exampleInputEmail1"
                                        placeholder="City "
                                       
                                    />
                                    
                                </div>
                            </div>
                            <div class="col-lg-offset-0 col-lg-6 col-xs-12 col-sm-12">
                                <div class="form-group">
                                    <label for="Gender" class="select">State</label>
                                    <input
                                        type=""
                                        class="form-control"
                                        id="exampleInputEmail1"
                                        placeholder="State"
                                       
                                    />
                                   

                                </div>
                            </div>
                            <div class="col-lg-offset-0 col-lg-6 col-xs-12 col-sm-12">
                                <div class="form-group">
                                    <label for="Gender" class="select">Address</label>
                                    <input
                                        type="text"
                                        class="form-control"
                                        id="exampleInputEmail1"
                                        placeholder="Address"
                                       
                                    />
                                   
                                </div>
                            </div>

                            <div class="col-lg-offset-0 col-lg-6 col-xs-12">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Pincode</label>
                                    <input
                                        type="text"
                                        class="form-control"
                                        id="exampleInputEmail1"
                                        placeholder="Pincode"
                                      
                                    />
                                   
                                </div>
                            </div>
                            <div class="col-lg-offset-0 col-lg-6 col-xs-12">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Website</label>
                                    <input
                                        type="text"
                                        class="form-control"
                                        id="exampleInputEmail1"
                                        placeholder="Website"
                                      
                                    />
                                   
                                </div>
                            </div>
                            

                            <div class="col-lg-offset-0 col-lg-6 col-xs-12 col-sm-12">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">School Documents Verification</label>
                                    <input
                                        type="file"
                                        class="form-control"
                                        id="exampleInputEmail1"
                                        placeholder="Upload Aadhar Photo"
                              
                                    />
                                   
                                </div>
                            </div>
                        </div>
                        <hr />
                        {/* <div class="modal fade" id="exitApplication" tabindex="-1" role="dialog" aria-labelledby="exitApplication">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                        <h4 class="modal-title" id="myModalLabel">Before you exit</h4>
                                    </div>
                                    <div class="modal-body">
                                        Do you want to save this application for later?
                                    </div>
                                    <div class="modal-footer">
                                        <a href="vcp.html" role="button" class="btn btn-default btn-large">Don't save</a>
                                        <a href="vcp.html" role="button" class="btn btn-success btn-large">Save</a>
                                    </div>
                                </div>
                            </div>
                        </div> */}
                        {/* <!-- /Exit (Are you sure?) Modal --> */}
                        <div class="pull-right">
                            <a role="button" class="btn btn-primary btn-large" >Submit</a>
                        </div>
                    </form>

                </div>
                {/* <!-- /Main Content -- */}
            </div>
        </Modal.Body>
       
      </Modal>
    </>
  );
}

export default UpdateSchool;