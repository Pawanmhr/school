import React, { useState,useEffect} from "react";
import { Link } from "react-router-dom";
import { DataGrid, GridToolbar } from '@mui/x-data-grid';
import { Button } from "reactstrap";
import { GetScholsarshipService } from "service/GetSchlorashipService";
import UpdateStudent from "./updateStudent";
import { useDispatch, useSelector } from "react-redux";
const Scholarship = () => {
    const dispatch=useDispatch()
    const data=useSelector((state)=>state?.GetScholarShipSlice?.scholar)
    const [selectedRowIds, setSelectedRowIds] = useState([]);
    const [selectedClass, setSelectedClass] = useState(''); // State for selected class filter
    const columns = [
        { field: 'id', headerName: 'Sr No', width: 150 },
        { field: 'name', headerName: ' Candidate Name', width: 150 },
        { field: 'Date', headerName: ' Date of Birth', width: 150 },

        { field: 'School', headerName: ' Current School', width: 150 },
        { field: 'Grade', headerName: 'Grade', width: 100 },
        { field: 'Address', headerName: 'Residential Address', width: 150 },
        { field: 'Number', headerName: 'Contact Number', width: 150 },
        { field: 'Email', headerName: 'Email Address', width: 150 },
        { field: 'Fathers', headerName: 'Fathers Name', width: 100 },
        { field: 'budget', headerName: 'Allotted Budget ', width: 150 },
      
    ];

    // Static data
    const modifiedData = Array.isArray(data) && data?.map((item,index)=>({
        id:index+1,
        name:item?.candidateName,
        Date:item?.dateOfBirth,
        School:item?.currentSchool,
        Grade:item?.studentGrade,
        Address:item?.residentialAddress,
        Number:item?.contactNumberOfStudent,
        Email:item?.emailAddressOfStudent,
        Fathers:item?.fatherName,
        budget:item?.allotedBudget


    }))

    const handleRowClick = (params) => {
        const { id } = params.row;
        if (selectedRowIds.includes(id)) {
            setSelectedRowIds(prevSelectedRowIds =>
                prevSelectedRowIds.filter(rowId => rowId !== id)
            );
        } else {
            setSelectedRowIds(prevSelectedRowIds => [...prevSelectedRowIds, id]);
        }
    };

    const handleClassChange = (event) => {
        setSelectedClass(event.target.value); // Update selected class filter
    };

    // Filter data based on selected class
    const filteredData = selectedClass ? modifiedData.filter(student => student.City === selectedClass) : modifiedData;
    useEffect(()=>{
        dispatch(GetScholsarshipService())
    },[dispatch])

    return (
        <>
            <div className="content">

                <div className="" style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <div style={{display:'flex', gap:"10px"}}>
               
                    </div>

                    <Button style={{ background: 'rgba(18, 113, 215, 1)', color: 'white' }}>
                        <Link to='/admin/AddStudent'><i class="fa-solid fa-bell"></i> Notifications</Link>
                    </Button>
                </div>
                {/* Select input for class filter */}
               
                <DataGrid
                    columns={columns}
                    rows={modifiedData}
                    disableColumnFilter
                    disableDensitySelector
                    slots={{ toolbar: GridToolbar }}
                    selectionModel={selectedRowIds}
                    onRowClick={handleRowClick}
                />
            </div>
        </>
    );
}

export default Scholarship;
