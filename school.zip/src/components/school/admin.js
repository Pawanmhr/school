import React, { useState } from "react";
import { Link } from "react-router-dom";
import { DataGrid, GridToolbar } from '@mui/x-data-grid';
import { Button } from "reactstrap";
import UpdateAdmin from "./editAdmin";
const AllAdmin = () => {
    const [selectedRowIds, setSelectedRowIds] = useState([]);

    const columns = [
        { field: 'id', headerName: 'Sr No', width: 150 },
        { field: 'name', headerName: ' First Name', width: 150 },
        { field: 'Address', headerName: 'Last Name', width: 150 },
        { field: 'City', headerName: 'Address', width: 100 },
        { field: 'State', headerName: 'Contact Number ', width: 150 },
        { field: 'pin', headerName: ' Email Address', width: 150 },
      
        {
            field: 'action',
            headerName: 'Action',
            width: 100,
            renderCell: (params) => (
                <>
                        <button  style={{ textDecoration: "none", border: "none", outline: "none", background: "none" }}>
                           <UpdateAdmin/>
                        </button>
                </>
            ),
        },
    ];

    // Static data
    const modifiedData = [
        { id: 1, orderId: 1234, name: 'John Doe', Address: 'Address', City: 'City', State: 'State',pin: 'pincode', mobile: 'mobile', Document: 'State',Email: 'Email', Website: 'Website'  },
       
        // Add more static data as needed
    ];

    const handleRowClick = (params) => {
        const { id } = params.row;
        if (selectedRowIds.includes(id)) {
            setSelectedRowIds(prevSelectedRowIds =>
                prevSelectedRowIds.filter(rowId => rowId !== id)
            );
        } else {
            setSelectedRowIds(prevSelectedRowIds => [...prevSelectedRowIds, id]);
        }
    };

    return (
        <>
    
        <div className="content">
        <div className="" style={{display:'flex',justifyContent:'end'}}>
            <Button style={{background:'rgb(18, 113, 215)'}}><Link to='/admin/CreateAdmin'> Create Admin</Link></Button>
        </div>
            <DataGrid
                columns={columns}
                rows={modifiedData}
                disableColumnFilter
                disableDensitySelector
                slots={{ toolbar: GridToolbar }}
                selectionModel={selectedRowIds}
                onRowClick={handleRowClick}
            />
        </div>
        </>
    );
}

export default AllAdmin;
