import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import Modal from 'react-bootstrap/Modal';
import { DataGrid, GridToolbar } from '@mui/x-data-grid';
import { Spinner } from "reactstrap";

import { Button } from "reactstrap";
import { GetPendingStudentService } from "service/PendingStudentService";
import { StatusApprovedService } from "service/statusApprovedStudentService";
import { sucessToast } from "toast/toast";
import UpdateStudent from "./updateStudent";
import { useDispatch, useSelector } from "react-redux";
import { GetStudentByIdService } from "service/getStudentByIdService";
import { UpdateStudentService } from 'service/updateStudentService';
import { GetApprovedSchoolService } from "service/getApproveSchoolService";
import { FileService } from "service/fileService";
import { Document, Page, pdfjs } from 'react-pdf';
import RemoveRedEyeIcon from '@mui/icons-material/RemoveRedEye';
pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.min.js`;

const Pending = () => {
    const navigate=useNavigate()
    const studentIds = useSelector((state) => state?.GetstudentByIdSlice?.school)
    const loading = useSelector((state) => state?.UpdateStudentSlice?.loading)
    const school = useSelector((state) => state?.getApprovedSchoolSlice?.admin)

    const dispatch=useDispatch()
    const [show, setShow] = useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    const data=useSelector((state)=>state?.GetPendingStudentSlice?.pending)
    const [selectedRowIds, setSelectedRowIds] = useState([]);
    const [selectedClass, setSelectedClass] = useState(''); // State for selected class filter
    const renderStatusDropdown = (params) => (
        <select
        style={{ background: params.row.Status === 'Pending' ? 'orange' : '',color:'white',fontWeight:'700',position:'relative',right:'10px' }}
        onChange={(event) => handleChangeStatus(event, params.row.id)}
        value={params.row.Status}
    >
        <option value="Approved" style={{color:'green'}}>
            Approved
        </option>
        <option
            value="Pending"
            className={params.row.status === 'Pending' ? 'pending' : ''}
        >
            Pending
        </option>
    </select>
    
    );
    const columns = [
        { field: 'sno', headerName: 'Sno.', width: 150 },

        { field: 'id', headerName: 'Student Id', width: 150 },
        { field: 'name', headerName: ' Candidate Name', width: 150 },
        { field: 'Current', headerName: ' Current School', width: 150 },

        { field: 'Grade', headerName: 'Grade', width: 100 },
        { field: 'State', headerName: 'Residential Address', width: 150 },
        { field: 'Contact', headerName: 'Contact Number', width: 150 },
        {
            field: 'Document', headerName: 'Document', width: 100, renderCell: (params) => (
                <>
                    {/* ${params?.row.Document} */}
                    <p  style={{ color: 'black' ,cursor:'pointer',position:'relative',top:'10px'}}  onClick={()=>handleurl(params?.row.Document)}>
                    <RemoveRedEyeIcon/>    View Doc</p> 
                </>
            )
        },
        { field: 'Email', headerName: 'Email Address', width: 150 },
        { field: 'Fathers', headerName: 'Fathers Name', width: 100 },
        { field: 'Fathersp', headerName: 'Fathers Profession ', width: 150 },

        {
            field: 'status',
            headerName: 'Status',
            width: 100,
            renderCell: renderStatusDropdown,
        },
        {
            field: 'action',
            headerName: 'Action',
            width: 100,
            renderCell: (params) => (
                <>
                    <div style={{ background: 'rgb(18, 113, 215)', color: 'white', padding: '5px' }}>
                        <button onClick={(event) => handClick(params?.id, event)} style={{ textDecoration: "none", border: "none", outline: "none", background: "none", color: 'white' }}>
                            Edit
                        </button>

                    </div>
                </>
            ),
        },
    ];
    const handClick = async (id, event) => {

        // Dispatch an asynchronous action to fetch student by ID

        dispatch(GetStudentByIdService(id));
        handleShow()
        // Assuming studentData contains the ID of the fetched student
        // Update the studentIds state with the fetched student's ID

    };
   
    const handleChangeStatus = async(event,id) => {
        console.log(id)
        const { value } = event.target;
        const data={
            value,id
        }
      await  dispatch(StatusApprovedService(data)).unwrap()
      await dispatch(GetPendingStudentService()).unwrap()
      sucessToast('Status Updated Successfully')

        // Update the row's status in the state
        // You may need to update your state management logic here
    }

    const modifiedData = Array.isArray(data) && data?.map((item,index)=>({
        sno:index+1,
        id: item.studentId,
        name: item.candidateName,
        Current: item.currentSchool,
        Grade: item.studentGrade,
        State: item.residentialAddress,
        Contact: item.contactNumberOfStudent,
        Email: item?.emailAddressOfStudent,
        Fathers: item?.fatherName,
        Fathersp: item?.fatherProfession,
        Status:item?.studentStatus,
        Document:item?.studentReceipt
    }))
    const handleRowClick = (params) => {
        const { id } = params.row;
        if (selectedRowIds.includes(id)) {
            setSelectedRowIds(prevSelectedRowIds =>
                prevSelectedRowIds.filter(rowId => rowId !== id)
            );
        } else {
            setSelectedRowIds(prevSelectedRowIds => [...prevSelectedRowIds, id]);
        }
    };

    const handleClassChange = (event) => {
        setSelectedClass(event.target.value); // Update selected class filter
    };


     useEffect(()=>{
   dispatch(GetPendingStudentService())
   dispatch(GetApprovedSchoolService())
     },[dispatch])



    // Filter data based on selected class
    const filteredData = selectedClass ? modifiedData.filter(student => student.City === selectedClass) : modifiedData;

    const [student, setStudent] = useState({
        fname: "",
        fprofession: "",
        fincome: '',
        fadhar: "",
        fpancard: '',
        mothername: "",
        mprofession: "",
        mincome: "",
        madhar: '',
        mpancard: "",
        numofChild: "",
        candidatename: "",
        grade: "",
        dob: "",
        currentSchool: "",
        residentaladdress: '',
        contactnumber: '',
        stuemail: "",
        Marks: "",
        term: "",
        gradeFieldToSetGrade:"",
        amount :""
    })
    const handleChange = (e) => {
        const { name, value } = e.target
        setStudent({
            ...student,
            [name]: value
        })
    }
    const [file, setFile] = useState({
        fadharfile: "",
        fatherpanfile: "",
        motheradharcardfile: "",
        motherpanfile: "",
        reciept: "",
        idPrrofImage:""
    })
    const handleFile = (event) => {
        const { name, files } = event.target;
        setFile(prevState => ({
            ...prevState,
            [name]: files[0] // or simply files if you want to store the entire array
        }));
    }



    useEffect(() => {
        setStudent((pre) => ({
            ...pre,
            fname: studentIds?.fatherName,
            fprofession: studentIds?.fatherProfession,
            fincome: studentIds?.fatherIncome,
            fadhar: studentIds?.aadhaarCardNumber1,
            fpancard: studentIds?.panCardNumber1,
            mothername: studentIds?.motherName,
            mprofession: studentIds?.motherProfession,
            mincome: studentIds?.motherIncome,
            madhar: studentIds?.aadhaarCardNumber2,
            mpancard: studentIds?.panCardNumber2,
            numofChild: studentIds?.numberOfChildren,
            candidatename: studentIds?.studentDetails?.name,
            grade: studentIds?.grade,
            dob: studentIds?.dateOfBirth,
            currentSchool: studentIds?.currentSchool,
            residentaladdress: studentIds?.residentialAddress?.state,
            contactnumber: studentIds?.studentDetails?.phoneNumber,
            stuemail: studentIds?.studentDetails?.email,
            Marks: studentIds?.marks,
            term: studentIds?.terms,
            gradeFieldToSetGrade:studentIds?.gradeFieldToSetGrade,
            amount :studentIds?.amount
        }))

        setInputValue(studentIds?.currentSchool)

    }, [studentIds])
    const [inputValue, setInputValue] = useState('');
    const [suggestions, setSuggestions] = useState([]);
    const [selectedSchool, setselectedschool] = useState();

    const handleSchoolchange = (e) => {
        const { name, value } = e.target;
        setInputValue(value)

        if (value === '') {
            // Clear suggestions if input value is empty
            setSuggestions([]);
        } else {
            // Filter suggestions based on the input value
            const filteredSchools = school.filter(item => item.schoolName.toLowerCase().includes(value.toLowerCase()));
            setSuggestions(filteredSchools);
        }
    }

    const handleSelectSchool = (selectedSchool) => {
        // Update the input value with the selected school name
        setselectedschool(selectedSchool)
        setInputValue(selectedSchool.schoolName);
        setSuggestions([]);

    };

    const handleClcik = async (e) => {
        e.preventDefault()
        const id = studentIds?.studentId
        const data = {
            file, student, id, selectedSchool
        }
        await dispatch(UpdateStudentService(data)).unwrap()
      
        handleClose()
    }


    const handleurl = async (urlss) => {
        localStorage.setItem('url',urlss)
      await  dispatch(FileService(urlss));
        window.open('/admin/pdfview', '', '');
       
    };

    return (
        <>
        <style>
        {
            
            `
            .modal-dialog {
                max-width: 58%;
                margin: 1.75rem auto;
            }
            select {
              padding: 10px;
              background: white;
              margin-right: 7px;
              width:100%;
          }
            select {
                PADDING: 4PX;
                BORDER: NONE;
                BACKGROUND: aliceblue;
                POSITION: RELATIVE;
            }
            
            
            `
        }
        </style>
            <div className="content">

                <div className="" style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <div style={{display:'flex', gap:"10px"}}>
               
                    </div>

                    <Button style={{ background: 'rgba(18, 113, 215, 1)', color: 'white' }}>
                        <Link to='/admin/AddStudent'><i class="fa-solid fa-plus"></i> Add Students</Link>
                    </Button>
                </div>
                {/* Select input for class filter */}
               
                <DataGrid
                    columns={columns}
                    rows={filteredData}
                    disableColumnFilter
                    disableDensitySelector
                    slots={{ toolbar: GridToolbar }}
                    selectionModel={selectedRowIds}
                    onRowClick={handleRowClick}
                />

            </div>
            <Modal show={show} onHide={handleClose}>
                <Modal.Header closeButton>

                </Modal.Header>
                <Modal.Body>
                <div className="content">
                        {/* <!-- Main Content --> */}
                        <div class="col-xs-12 col-lg-12 col-sm-12 col-md-12 mt-4" >
                            <h4 style={{ fontWeight: '700' }}>Candidate Information</h4>
                            <div class="row">
                                <div class="col-lg-6 col-xs-12 col-sm-6">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Candidate Name</label>
                                        <input
                                            value={student?.candidatename}
                                            onChange={handleChange}
                                            name="candidatename"
                                            type="text"
                                            class="form-control"
                                            id="exampleInputEmail1"
                                            placeholder="Candidate Name"

                                        />

                                    </div>
                                </div>

                                <div class="col-lg-offset-0 col-lg-6 col-xs-12 col-sm-6">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Class</label>
                                        <input
                                            value={student?.grade}
                                            onChange={handleChange}
                                            name='grade'
                                            type="text"
                                            class="form-control"
                                            id="exampleInputEmail1"
                                            placeholder="class"
                                        />
                                    </div>
                                </div>
                                <div class="col-lg-offset-0 col-lg-6 col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label for="Gender" class="select" style={{ width: '100%' }}>Grade</label>
                                    <input
                                            value={student?.gradeFieldToSetGrade}

                                        onChange={handleChange}
                                        name="gradeFieldToSetGrade"
                                        type="text"
                                        class="form-control"
                                        id="exampleInputEmail1"
                                        placeholder="Grade"
                                    />


                            </div>
                        </div>
                        <div class="col-lg-offset-0 col-lg-6 col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label for="Gender" class="select" style={{ width: '100%' }}>Student Id Proof</label>
                               
                                    <input
                                        onChange={handleFile}
                                        name="idPrrofImage"
                                        type="file"
                                        class="form-control"
                                        id="exampleInputEmail1"
                                        placeholder="FILE"
                                    />

                            </div>
                            <Button  onClick={() => handleurl(studentIds?.idPrrofImage)}>
                                                View document
                                            </Button>
                        </div>
                                <div class="col-lg-offset-0 col-lg-6 col-xs-12 col-sm-6">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Date of Birth</label>
                                        <input
                                            name="dob"
                                            value={student?.dob}
                                            onChange={handleChange}
                                            type="date"
                                            class="form-control"
                                            id="exampleInputEmail1"

                                        />

                                    </div>
                                </div>


                                <div class="col-lg-offset-0 col-lg-6 col-xs-12 col-sm-12">
                                    <label for="Gender" class="select">Current School </label>
                                    <div class="form-group">

                                        <input
                                            placeholder="Type to search school"
                                            name="currentSchool"
                                            onChange={handleSchoolchange}
                                            value={inputValue}

                                            type="text"
                                            class="form-control"
                                            id="exampleInputEmail1"
                                        />
                                        <div id="suggestions">
                                            {suggestions.map((item, index) => (
                                                <div
                                                    key={index}
                                                    className="suggestion-item"
                                                    onClick={() => handleSelectSchool(item)}
                                                >
                                                    <p>    {item.schoolName}</p>
                                                </div>
                                            ))}
                                        </div>


                                    </div>
                                </div>
                                <div class="col-lg-offset-0 col-lg-6 col-xs-12 col-sm-12">
                                    <div class="form-group">
                                        <label for="Gender" class="select">Residential Address</label>
                                        <input

                                            name="residentaladdress"
                                            value={student?.residentaladdress}
                                            onChange={handleChange}
                                            type=""
                                            class="form-control"
                                            id="exampleInputEmail1"
                                            placeholder="Residential Address"

                                        />
                                    </div>
                                </div>
                                <div class="col-lg-offset-0 col-lg-6 col-xs-12 col-sm-12">
                                    <div class="form-group">
                                        <label for="Gender" class="select">Contact Number</label>
                                        <input
                                            name="contactnumber"
                                            value={student?.contactnumber}
                                            onChange={handleChange}
                                            type="text"
                                            class="form-control"
                                            id="exampleInputEmail1"
                                            placeholder="Contact Number"

                                        />

                                    </div>
                                </div>

                                <div class="col-lg-offset-0 col-lg-6 col-xs-12">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Email Address</label>
                                        <input
                                            name="stuemail"
                                            value={student?.stuemail}
                                            onChange={handleChange}
                                            type="email"
                                            class="form-control"
                                            id="exampleInputEmail1"
                                            placeholder="Email Address"
                                        />

                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Marks</label>
                                        <input
                                            name="Marks"
                                            value={student?.Marks}
                                            onChange={handleChange}
                                            type="text"
                                            class="form-control"
                                            id="exampleInputEmail1"
                                            placeholder="marks"
                                        />
                                    </div>
                                    
                                </div>
                                <div class="col-lg-offset-0 col-lg-6 col-xs-6 col-sm-3">
                                        <div class="form-group">
                                            <label for="Gender" class="select" style={{ width: '100%' }}>Student Reciept</label>
                                            <input
                                            
                                                onChange={handleFile}
                                                name="reciept"
                                                type="file"
                                                class="form-control"
                                                id="exampleInputEmail1"
                                                placeholder="FILE"
                                            />


                                        </div>
                                        <Button  onClick={() => handleurl(studentIds?.studentReceiptPath)}>
                                                View document
                                            </Button>
                                    </div>
                       
                       
                                    <div class="col-lg-offset-0 col-lg-6 col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label for="Gender" class="select" style={{ width: '100%' }}>Amount</label>
                                    <input
                                            value={student?.amount}

                                        onChange={handleChange}
                                        name="amount"
                                        type="number"
                                        class="form-control"
                                        id="exampleInputEmail1"
                                        placeholder="Amount"
                                    />


                            </div>
                        </div>
                       


                                <div class="col-lg-offset-0 col-lg-6 col-xs-12">
                                    <label for="exampleInputEmail1">Select Semester</label>
                                    <div class="form-group">
                                        <select name="term" value={student?.term}
                                            onChange={handleChange}
                                        >
                                            <option value="1 semester">1 semester</option>
                                            <option value="2 semester">2 semester</option>
                                            <option value="3 semester">3 semester</option>
                                            <option value="4 semester">4 semester</option>
                                            <option value="5 semester">5 semester</option>
                                            <option value="6 semester">6 semester</option>
                                            <option value="Monthly">Monthly</option>
                                            <option value="Annualy">Annualy</option>



                                        </select>

                                    </div>

                                </div>
                            </div>
                            <hr />

                            <h4>Family Information</h4>
                            <div class="row">
                                <div class="col-lg-6 col-xs-12 col-sm-4">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Father's Name</label>
                                        <input
                                            value={student?.fname}
                                            onChange={handleChange}
                                            name="fname"
                                            type=""
                                            class="form-control"
                                            id="exampleInputEmail1"
                                            placeholder="Father's Name"

                                        />

                                    </div>
                                </div>

                                <div class="col-lg-offset-0 col-lg-3 col-xs-12 col-sm-4">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Father's Profession</label>
                                        <input
                                            value={student?.fprofession}
                                            onChange={handleChange}
                                            name="fprofession"
                                            type="text"
                                            class="form-control"
                                            id="exampleInputEmail1"
                                            placeholder="Father's Profession"

                                        />

                                    </div>
                                </div>

                                <div class="col-lg-offset-0 col-lg-3 col-xs-12 col-sm-4">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Father's Income</label>
                                        <input
                                            value={student?.fincome}
                                            onChange={handleChange}
                                            name="fincome"
                                            type=""
                                            class="form-control"
                                            id="exampleInputEmail1"
                                            placeholder='Father income'

                                        />

                                    </div>
                                </div>



                                <div class="col-lg-offset-0 col-lg-6 col-xs-6 col-sm-3">
                                    <div class="form-group">
                                        <label for="Gender" class="select">Aadhaar Card  </label>
                                        <div class="form-group">
                                            <label for="Gender" class="select"></label>
                                            <input
                                                name="fadhar"
                                                value={student?.fadhar}
                                                onChange={handleChange}
                                                type="text"
                                                class="form-control"
                                                id="exampleInputEmail1"
                                                placeholder="Aadhaar Card "
                                            />
                                            {/* <input
                                            onChange={handleFile}
                                            name="fadharfile"
                                            type="file"
                                            class="form-control"
                                            id="exampleInputEmail1"
                                            placeholder="FILE"

                                        /> */}
                                            <div class="form-group">


                                                <Button onClick={() => handleurl(studentIds?.aadhaarCardImage1)}>
                                                    View document
                                                </Button>


                                            </div>

                                        </div>

                                    </div>
                                </div>

                                <div class="col-lg-offset-0 col-lg-6 col-xs-6 col-sm-3">
                                    <div class="form-group">
                                        <label for="Gender" class="select">PAN Card </label>
                                        <div class="form-group">
                                            <label for="exampleInputEmail1"></label>
                                            <input
                                                name="fpancard"
                                                value={student?.fpancard}
                                                onChange={handleChange}
                                                type="text"
                                                class="form-control"
                                                id="exampleInputEmail1"
                                                placeholder="PAN Card "
                                            />
                                            {/* <input
                                            onChange={handleFile}
                                            name="fatherpanfile"
                                            type="file"
                                            class="form-control"
                                            id="exampleInputEmail1"
                                            placeholder="Email Address"
                                        /> */}
                                        </div>
                                        <div class="form-group">

                                            <Button onClick={() => handleurl(studentIds?.panCardImage1)}>
                                                View document
                                            </Button>
                                        </div>

                                    </div>
                                </div>


                                <div class="col-lg-6 col-xs-12 col-sm-4">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Mother's Name</label>
                                        <input
                                            name="mothername"
                                            value={student?.mothername}
                                            onChange={handleChange}
                                            type="text"
                                            class="form-control"
                                            id="exampleInputEmail1"
                                            placeholder="Mother's Name"
                                        />

                                    </div>
                                </div>

                                <div class="col-lg-offset-0 col-lg-3 col-xs-12 col-sm-4">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Mother's Profession</label>
                                        <input
                                            name="mprofession"
                                            value={student?.mprofession}
                                            onChange={handleChange}
                                            type="text"
                                            class="form-control"
                                            id="exampleInputEmail1"
                                            placeholder="Mother's Profession"

                                        />

                                    </div>
                                </div>

                                <div class="col-lg-offset-0 col-lg-3 col-xs-12 col-sm-4">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Mother's Income</label>
                                        <input
                                            name="mincome"
                                            value={student?.mincome}
                                            onChange={handleChange}
                                            type=""
                                            class="form-control"
                                            id="exampleInputEmail1"
                                            placeholder='Mother Income'

                                        />

                                    </div>

                                </div>


                                <div class="col-lg-offset-0 col-lg-6 col-xs-6 col-sm-3">
                                    <div class="form-group">
                                        <label for="Gender" class="select">Aadhaar Card  </label>
                                        <div class="form-group">
                                            <label for="Gender" class="select"></label>
                                            {/* <input
                                            name="motheradharcardfile"
                                            onChange={handleFile}
                                            type="file"
                                            class="form-control"
                                            id="exampleInputEmail1"
                                            placeholder="FILE"

                                        /> */}
                                            <input
                                                name="madhar"
                                                value={student?.madhar}
                                                onChange={handleChange}
                                                type="text"
                                                class="form-control"
                                                id="exampleInputEmail1"
                                                placeholder="Aadhaar Card "

                                            />


                                        </div>
                                        <div class="form-group">
                                            <Button onClick={() => handleurl(studentIds?.aadhaarCardImage2)}>
                                                View document
                                            </Button>

                                        </div>

                                    </div>
                                </div>

                                <div class="col-lg-offset-0 col-lg-6 col-xs-6 col-sm-3">
                                    <div class="form-group">
                                        <label for="Gender" class="select">PAN Card </label>
                                        <div class="form-group">
                                            <label for="exampleInputEmail1"></label>
                                            {/* <input
                                            name="motherpanfile"
                                            onChange={handleFile}

                                            type="file"
                                            class="form-control"
                                            id="exampleInputEmail1"
                                            placeholder="Email Address"

                                        /> */}
                                            <input
                                                name="mpancard"
                                                value={student.mpancard}
                                                onChange={handleChange}
                                                type="text"
                                                class="form-control"
                                                id="exampleInputEmail1"
                                                placeholder="PAN Card "

                                            />

                                        </div>
                                        <div class="form-group">
                                            <Button onClick={() => handleurl(studentIds?.panCardImage2)}>
                                                View document
                                            </Button>


                                        </div>


                                    </div>
                                </div>


                                <div class="col-lg-offset-0 col-lg-6     col-xs-3">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Number of Children in the Family</label>
                                        <input
                                            value={student?.numofChild}
                                            onChange={handleChange}
                                            name='numofChild'
                                            type="number"
                                            class="form-control"
                                            id="exampleInputEmail1"
                                            placeholder="Number of Children in the Family"

                                        />

                                    </div>
                                </div>
                            </div>



                            {/* <div class="modal fade" id="exitApplication" tabindex="-1" role="dialog" aria-labelledby="exitApplication">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                        <h4 class="modal-title" id="myModalLabel">Before you exit</h4>
                                    </div>
                                    <div class="modal-body">
                                        Do you want to save this application for later?
                                    </div>
                                    <div class="modal-footer">
                                        <a href="vcp.html" role="button" class="btn btn-default btn-large">Don't save</a>
                                        <a href="vcp.html" role="button" class="btn btn-success btn-large">Save</a>
                                    </div>
                                </div>
                            </div>
                        </div> */}
                            {/* <!-- /Exit (Are you sure?) Modal --> */}
                            <div class="pull-right">
                                <Button role="button" type='submit' class="btn btn-primary btn-large" style={{ background: 'rgb(18, 113, 215)', color: 'white', marginTop: '30px' }} onClick={handleClcik}>
                                    {
                                        loading ? (
                                            <>
                                                <Spinner
                                                    thickness='10px'
                                                    speed='0.65s'
                                                    emptyColor='blue'
                                                    color='blue.500'
                                                    size='sm'
                                                />
                                            </>
                                        ) : 'Submit'
                                    }
                                </Button>
                            </div>
                        </div>
                        {/* <!-- /Main Content -- */}
                    </div>
                </Modal.Body>

            </Modal>

        </>
    );
}

export default Pending;
