import * as React from 'react';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import useMediaQuery from '@mui/material/useMediaQuery';
import { useTheme } from '@mui/material/styles';
import { Input,TextField } from '@mui/material';
import Box from '@mui/material/Box';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';

export default function AllotBudget() {
  const [open, setOpen] = React.useState(false);
  const theme = useTheme();
  const [age, setAge] = React.useState('');

  const handleChange = (event) => {
    setAge(event.target.value);
  };

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  return (
    <>
    <style>
    {
        `.css-qfso29-MuiTypography-root-MuiDialogContentText-root {
            margin: 25px;
            font-family: "Roboto", "Helvetica", "Arial", sans-serif;
            font-weight: 400;
            font-size: 1rem;
            line-height: 5.5;
            letter-spacing: 0.00938em;
            color: rgba(0, 0, 0, 0.6);
        }`
    }
    </style>


    <React.Fragment>
      <Button onClick={handleClickOpen} style={{background:'rgba(197, 189, 10, 1)',color:'white'}}>
      Allot Budget 
      </Button>
      <Dialog
        open={open}
        onClose={handleClose}
        aria-labelledby="responsive-dialog-title"
      >
        <DialogTitle id="responsive-dialog-title">
          {"Allot Budget"}
        </DialogTitle>
        <DialogContent>
          <DialogContentText>
                  
<FormControl fullWidth>
  <InputLabel id="demo-simple-select-label">Select School</InputLabel>
  <Select
    labelId="demo-simple-select-label"
    id="demo-simple-select"
    value={age}
    label="Select School"
    onChange={handleChange}
  >
    <MenuItem value={10}>Ten</MenuItem>
    <MenuItem value={20}>Twenty</MenuItem>
    <MenuItem value={30}>Thirty</MenuItem>
  </Select>
</FormControl>
          <TextField 
  id="demo-helper-text-aligned"
  placeholder='budget'
/>

          </DialogContentText>
          <Button variant="contained"  style={{marginTop:'10px'}}>Save</Button>

        </DialogContent>
     
      </Dialog>
    </React.Fragment>
    </>
   
  );
}
