import React, { useState } from "react";
import { Link } from "react-router-dom";
import { DataGrid, GridToolbar } from '@mui/x-data-grid';
import { Button } from "reactstrap";
import {
    Card,
    CardHeader,
    CardBody,
    CardFooter,
    CardTitle,
    Row,
    Col,
  } from "reactstrap";
  import pic1 from '../../assets/img/dfive.png'
import pic2 from '../../assets/img/dfor.png'
import pic3 from '../../assets/img/dthre.png'
import pic4 from '../../assets/img/dfor.png'
import pic5 from '../../assets/img/done.png'
import pic7 from '../../assets/img/dtwo.png'
import AddBudget from "./allotbudget";
import AllotBudget from "./addbudget";
const Budget = () => {
    const [selectedRowIds, setSelectedRowIds] = useState([]);

    const columns = [
        { field: 'id', headerName: 'Sr No', width: 150 },
        { field: 'name', headerName: ' School Name', width: 150 },
        { field: 'Address', headerName: 'Address', width: 150 },
        { field: 'City', headerName: 'City', width: 100 },
        { field: 'State', headerName: 'State', width: 150 },
        { field: 'pin', headerName: ' Pin Code', width: 150 },
        { field: 'mobile', headerName: 'Contact Number', width: 150 },
        { field: 'Document', headerName: 'Document', width: 100 },
        { field: 'Email', headerName: 'Email Address ', width: 150 },
        { field: 'Website', headerName: 'Website', width: 100 },
      
        {
            field: 'action',
            headerName: 'Action',
            width: 100,
            renderCell: (params) => (
                <>
                    <Link to={`/admin/view-order-details/${params.row.id}`}>
                        <button  style={{ textDecoration: "none", border: "none", outline: "none", background: "none" }}>
                            <i className="fa fa-pencil-square-o"></i> View
                        </button>
                    </Link>
                </>
            ),
        },
    ];

    // Static data
    const modifiedData = [
        { id: 1, orderId: 1234, name: 'John Doe', Address: 'Address', City: 'City', State: 'State',pin: 'pincode', mobile: 'mobile', Document: 'State',Email: 'Email', Website: 'Website'  },
       
        // Add more static data as needed
    ];

    const handleRowClick = (params) => {
        const { id } = params.row;
        if (selectedRowIds.includes(id)) {
            setSelectedRowIds(prevSelectedRowIds =>
                prevSelectedRowIds.filter(rowId => rowId !== id)
            );
        } else {
            setSelectedRowIds(prevSelectedRowIds => [...prevSelectedRowIds, id]);
        }
    };

    return (
        <>
        <style>
          {
            `
            .main-panel > .content{
              margin-top: unset !important;
          }`
          }
        </style>
     <Row style={{marginTop:'70px',marginLeft:'17px'}}>
          
         
          <Col lg="4" md="6" mt="6" sm="6" >
            <Card className="card-stats">
              <CardBody>
              <Row>
                <Col md="6" xs="6">
                    <div className="numbers">
                      <p className="card-category">Budget Allotted
by Trustee
</p>
                      <p />
                    </div>
                  </Col>
                  <Col md="4" xs="5" style={{height:"100px"}}>
                    <div className="icon-big text-center icon-warning">
                      <img src={pic3}/>
                    </div>
                  </Col>
                  <Col md="6" xs="6">
                    <div className="numbers">
                      <CardTitle className="num" tag="p">₹ 20,00,000 </CardTitle>
                      <p />
                    </div>
                  </Col>
                </Row>
              </CardBody>
              <CardFooter>
                <hr />
                <div className="stats">
                  <i className="fas fa-sync-alt" /> Update now
                </div>
              </CardFooter>
            </Card>
          </Col>
          <Col lg="4" md="6" sm="6">
            <Card className="card-stats">
              <CardBody>
              <Row>
                <Col md="6" xs="6">
                    <div className="numbers">
                      <p className="card-category">Budget Allotted
to Students</p>
                      <p />
                    </div>
                  </Col>
                  <Col md="4" xs="5" style={{height:"100px"}}>
                    <div className="icon-big text-center icon-warning">
                      <img src={pic7}/>
                    </div>
                  </Col>
                  <Col md="6" xs="6">
                    <div className="numbers">
                      <CardTitle className="num" tag="p">₹ 10,00,000</CardTitle>
                      <p />
                    </div>
                  </Col>
                </Row>
              </CardBody>
              <CardFooter>
                <hr />
                <div className="stats">
                  <i className="fas fa-sync-alt" /> Update Now
                </div>
              </CardFooter>
            </Card>
          </Col>

          <Col lg="4" md="6" sm="6">
            <Card className="card-stats">
              <CardBody>
              <Row>
                <Col md="6" xs="6">
                    <div className="numbers">
                      <p className="card-category">Remaining 
Budget</p>
                      <p />
                    </div>
                  </Col>
                  <Col md="4" xs="5" style={{height:"100px"}}>
                    <div className="icon-big text-center icon-warning">
                      <img src={pic2}/>
                    </div>
                  </Col>
                  <Col md="6" xs="6">
                    <div className="numbers">
                      <CardTitle className="num" tag="p">1000+</CardTitle>
                      <p />
                    </div>
                  </Col>
                </Row>
              </CardBody>
              <CardFooter>
                <hr />
                <div className="stats">
                  <i className="far fa-calendar" /> Last day
                </div>
              </CardFooter>
            </Card>
          </Col>
         
    
        </Row>
        <div className="content">
        <div className="" style={{display:'flex',justifyContent:'end'}}>
         <Button style={{background:'rgba(197, 189, 10, 1)',color:'white'}}>  <AllotBudget/> </Button>  
            <Button style={{background:'rgba(18, 113, 215, 1)',color:'white'}}> <AddBudget/></Button>
        </div>
            <DataGrid
                columns={columns}
                rows={modifiedData}
                disableColumnFilter
                disableDensitySelector
                slots={{ toolbar: GridToolbar }}
                selectionModel={selectedRowIds}
                onRowClick={handleRowClick}
            />
        </div>
        </>
    );
}

export default Budget;
