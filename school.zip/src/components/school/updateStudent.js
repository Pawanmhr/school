import { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';

function UPdateBuget() {
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  return (
    <>
    <style>
      {
        `
        .modal-dialog {
          max-width: 58%;
          margin: 1.75rem auto;
      }
        `
      }
    </style>
      <Button variant="primary" onClick={handleShow} style={{background:'rgb(18, 113, 215)',color:'white',marginTop:'20px',marginLeft:'-18px'}}>
       
      Update
      </Button>

      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
        </Modal.Header>
        <Modal.Body>
        <div className="content">
                {/* <!-- Main Content --> */}
                <div class="col-xs-12 col-lg-12 col-sm-12 col-md-12 mt-4" >
                    <h4>Candidate Information</h4>
                    <form>
                        <div class="row">
                            <div class="col-lg-6 col-xs-12 col-sm-6">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Candidate Name</label>
                                    <input
                                        type="email"
                                        class="form-control"
                                        id="exampleInputEmail1"
                                        placeholder="Candidate Name"
                                      
                                    />
                                   
                                </div>
                            </div>

                            <div class="col-lg-offset-0 col-lg-6 col-xs-12 col-sm-6">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Grade</label>
                                    <input
                                        type="email"
                                        class="form-control"
                                        id="exampleInputEmail1"
                                        placeholder="Grade"
                                       
                                    />
                                   
                                </div>
                            </div>

                            <div class="col-lg-offset-0 col-lg-6 col-xs-12 col-sm-6">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Date of Birth</label>
                                    <input
                                        type="date"
                                        class="form-control"
                                        id="exampleInputEmail1"
                                       
                                    />
                                   
                                </div>
                            </div>



                            <div class="col-lg-offset-0 col-lg-6 col-xs-12 col-sm-12">
                                <div class="form-group">
                                    <label for="Gender" class="select">Current School </label>
                                    <input
                                        type="text"
                                        class="form-control"
                                        id="exampleInputEmail1"
                                        placeholder="Current School"
                                        disabled
                                       
                                    />
                                    
                                </div>
                            </div>
                            <div class="col-lg-offset-0 col-lg-6 col-xs-12 col-sm-12">
                                <div class="form-group">
                                    <label for="Gender" class="select">Residential Address</label>
                                    <input
                                        type=""
                                        class="form-control"
                                        id="exampleInputEmail1"
                                        placeholder="Residential Address"
                                       
                                    />
                                   

                                </div>
                            </div>
                            <div class="col-lg-offset-0 col-lg-6 col-xs-12 col-sm-12">
                                <div class="form-group">
                                    <label for="Gender" class="select">Contact Number</label>
                                    <input
                                        type="text"
                                        class="form-control"
                                        id="exampleInputEmail1"
                                        placeholder="Contact Number"
                                       
                                    />
                                   
                                </div>
                            </div>

                            <div class="col-lg-offset-0 col-lg-6 col-xs-12">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Email Address</label>
                                    <input
                                        type="text"
                                        class="form-control"
                                        id="exampleInputEmail1"
                                        placeholder="Email Address"
                                      
                                    />
                                   
                                </div>
                            </div>
                           
                        </div>
                        <hr />

                    <h4>Family Information</h4>
                     <div class="row">
                            <div class="col-lg-6 col-xs-12 col-sm-4">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Father's Name</label>
                                    <input
                                        type="email"
                                        class="form-control"
                                        id="exampleInputEmail1"
                                        placeholder="Father's Name"
                                      
                                    />
                                   
                                </div>
                            </div>

                            <div class="col-lg-offset-0 col-lg-3 col-xs-12 col-sm-4">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Budget Allot</label>
                                    <input
                                        type="email"
                                        class="form-control"
                                        id="exampleInputEmail1"
                                        placeholder="Budget Allot"
                                       
                                    />
                                   
                                </div>
                            </div>

           



                         

                         



                            
                         
                         
                          
                          
                        </div>
                        
                        

                        {/* <div class="modal fade" id="exitApplication" tabindex="-1" role="dialog" aria-labelledby="exitApplication">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                        <h4 class="modal-title" id="myModalLabel">Before you exit</h4>
                                    </div>
                                    <div class="modal-body">
                                        Do you want to save this application for later?
                                    </div>
                                    <div class="modal-footer">
                                        <a href="vcp.html" role="button" class="btn btn-default btn-large">Don't save</a>
                                        <a href="vcp.html" role="button" class="btn btn-success btn-large">Save</a>
                                    </div>
                                </div>
                            </div>
                        </div> */}
                        {/* <!-- /Exit (Are you sure?) Modal --> */}
                        <div class="pull-right">
                            <a role="button" style={{background:'rgba(224, 58, 58, 1)',color:'white'}} class="btn  btn-large" >Click here to allot</a>
                        </div>
                    </form>

                </div>
                {/* <!-- /Main Content -- */}
            </div>
        </Modal.Body>
       
      </Modal>
    </>
  );
}

export default UPdateBuget;