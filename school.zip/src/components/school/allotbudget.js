import * as React from 'react';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import useMediaQuery from '@mui/material/useMediaQuery';
import { useTheme } from '@mui/material/styles';
import { Input,TextField } from '@mui/material';

export default function AddBudget() {
  const [open, setOpen] = React.useState(false);
  const theme = useTheme();

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  return (
    <React.Fragment>
      <Button onClick={handleClickOpen} style={{background:'rgba(18, 113, 215, 1)',color:'white'}}>
      Add Budget
      </Button>
      <Dialog
        open={open}
        onClose={handleClose}
        aria-labelledby="responsive-dialog-title"
      >
        <DialogTitle id="responsive-dialog-title">
          {"Add Budget"}
        </DialogTitle>
        <DialogContent>
          <DialogContentText>
          <TextField 
  helperText="Please enter your Budget"
  id="demo-helper-text-aligned"
  placeholder='budget'
/>
      
          </DialogContentText>
          <Button variant="contained">Save</Button>

        </DialogContent>
     
      </Dialog>
    </React.Fragment>
  );
}
