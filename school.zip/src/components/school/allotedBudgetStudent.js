import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { DataGrid, GridToolbar } from '@mui/x-data-grid';
import { Button } from "reactstrap";
import {
    Card,
    CardHeader,
    CardBody,
    CardFooter,
    CardTitle,
    Row,
    Col,
  } from "reactstrap";
  import pic1 from '../../assets/img/dfive.png'
import pic2 from '../../assets/img/dfor.png'
import pic3 from '../../assets/img/dthre.png'
import pic4 from '../../assets/img/dfor.png'
import pic5 from '../../assets/img/done.png'
import pic7 from '../../assets/img/dtwo.png'
import AddBudget from "./allotbudget";
import AllotBudget from "./addbudget";
import { Input } from "@mui/material";
import UPdateBuget from "./updateStudent";
import { GetBugetDashboardService } from "service/GetBudgetDashBoardService";
import { useDispatch, useSelector } from "react-redux";
const AllotedBudgetStudent = () => {

  const dispatch=useDispatch()
  const Dash=useSelector((state)=>state?.GetDashBoardBugetSlice?.DASH)
   


  useEffect(()=>{
     dispatch(GetBugetDashboardService())
  },[dispatch])


    const [selectedRowIds, setSelectedRowIds] = useState([]);

    const columns = [
        { field: 'id', headerName: 'Sr No', width: 150 },
        { field: 'name', headerName: ' School Name', width: 150 },
        { field: 'Address', headerName: 'Address', width: 150 },
        { field: 'status', headerName: 'status', width: 100 },
        { field: 'fatherName', headerName: ' fatherName', width: 150 },
        { field: 'mobile', headerName: 'Contact Number', width: 150 },
        { field: 'allotedOn', headerName: 'allotedOn', width: 100 },
        { field: 'grade', headerName: 'grade', width: 100 },
      
//         {
//             field: 'action',
//             headerName: 'Action',
//             width: 100,
//             renderCell: (params) => (
//                 <>
//                         <button  style={{ textDecoration: "none", border: "none", outline: "none", background: "none" }}>
//  <UPdateBuget/>
//                         </button>
//                 </>
//             ),
//         },
    ];

    // Static data
    const modifiedData = Array.isArray(Dash) && Dash?.map((item,index)=>({
      id:index+1,
      name:item?.candidateName,
      Address:item?.residentialAddress,
      mobile:item?.contactNumber,
      status:item?.status,
      fatherName:item?.fatherName,
      allotedOn:item?.allotedOn,
      grade:item?.grade

    }))
    const handleRowClick = (params) => {
        const { id } = params.row;
        if (selectedRowIds.includes(id)) {
            setSelectedRowIds(prevSelectedRowIds =>
                prevSelectedRowIds.filter(rowId => rowId !== id)
            );
        } else {
            setSelectedRowIds(prevSelectedRowIds => [...prevSelectedRowIds, id]);
        }
    };

    return (
        <>
        <style>
          {
            `
            .main-panel > .content{
              margin-top: unset !important;
          }
          .centered{
            ma
          }
         
        .textfield {
           position: relative;
            padding: 10px 15px;
            border:1px solid #e3f2fd;
            border-radius:5px;
            box-shadow: none;
        }
        .centered span {
            position: absolute;
            z-index: 1;
            background-color:#fff;
            top: 13px;
            left: 15px;
            color:#A9A9A9;
            padding:0 5px;
        }
        .textfield:focus {
            border:1px solid #0d47a1;
        }
        input:focus ~ span,
        input:not(:focus):valid ~ span {
            top:-8px;
        }
        .textfield, span {
          transition: ease-in-out 0.2s all;
          -webkit-transition: ease-in-out 0.2s all;
          -moz-transition: ease-in-out 0.2s all;
          -o-transition: ease-in-out 0.2s all;
        }
          `
          }
        </style>
     <Row style={{marginTop:'70px',marginLeft:'17px'}}>
     

        {/* row */}

    
    
        </Row>
        <div className="content">
        <div className="" style={{display:'flex',justifyContent:'space-between'}}>

<Button style={{ background: 'rgba(18, 113, 215, 1)', color: 'white' }}>
<i class="fa-solid fa-bell"></i> Notifications
                    </Button>

        </div>
            <DataGrid
                columns={columns}
                rows={modifiedData}
                disableColumnFilter
                disableDensitySelector
                slots={{ toolbar: GridToolbar }}
                selectionModel={selectedRowIds}
                onRowClick={handleRowClick}
            />
        </div>
        </>
    );
}

export default AllotedBudgetStudent;
