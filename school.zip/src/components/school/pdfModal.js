import React, { useState } from 'react';
import { useSelector } from 'react-redux';
import { Spinner } from '@chakra-ui/react';
import { Document, Page } from 'react-pdf';
import { Button } from 'reactstrap';
import { Link } from 'react-router-dom';

const PdfModal = () => {
  const file = useSelector((state) => state?.FileReducer?.file);
  const url=localStorage.getItem('url')
  const [isLoading, setIsLoading] = useState(true);

  const isPdf = url && url.toLowerCase().endsWith('.pdf');

  const handleLoadSuccess = () => {
    setIsLoading(false);
  };

  return (
    <>
      <style>
        {`
          .mypddffffff {
            display: flex;
            justify-content: center;
          }
          canvas.react-pdf__Page__canvas {
            margin: auto;
          }
        `}
      </style>
      <div style={{display:'flex',justifyContent:'end'}}>

        <Button>
          <Link to={url}>
          Download Document
          </Link>
          </Button>
      </div>
      <div className='mypddffffff'>
        {isPdf ? (
          <Document file={url} onLoadSuccess={handleLoadSuccess}>
            <Page pageNumber={1} />
          </Document>
        ) : (
          <img src={url} alt="Image" onLoad={handleLoadSuccess} />
        )}
      </div>
    </>
  );
}

export default PdfModal;
