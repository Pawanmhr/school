import React, { useState } from "react";
import { Link } from "react-router-dom";
import { DataGrid, GridToolbar } from '@mui/x-data-grid';
import { Button } from "reactstrap";

import UpdateStudent from "./updateStudent";
const Students = () => {
    const [selectedRowIds, setSelectedRowIds] = useState([]);
    const [selectedClass, setSelectedClass] = useState(''); // State for selected class filter
    const columns = [
        { field: 'id', headerName: 'Sr No', width: 150 },
        { field: 'name', headerName: ' Candidate Name', width: 150 },
        { field: 'Address', headerName: ' Current School', width: 150 },
        { field: 'City', headerName: 'Grade', width: 100 },
        { field: 'State', headerName: 'Residential Address', width: 150 },
        { field: 'pin', headerName: 'Contact Number', width: 150 },
        { field: 'mobile', headerName: 'Email Address', width: 150 },
        { field: 'Document', headerName: 'Fathers Name', width: 100 },
        { field: 'Email', headerName: 'Fathers Profession ', width: 150 },
        {
            field: 'action',
            headerName: 'Action',
            width: 100,
            renderCell: (params) => (
                <>
                    <button style={{ textDecoration: "none", border: "none", outline: "none", background: "none" }}>
                        <UpdateStudent />
                    </button>
                </>
            ),
        },
    ];

    // Static data
    const modifiedData = [
        { id: 1, orderId: 1234, name: 'John Doe', Address: 'Address', City: 'City', State: 'State', pin: 'pincode', mobile: 'mobile', Document: 'State', Email: 'Email', Website: 'Website' },
        // Add more static data as needed
    ];

    const handleRowClick = (params) => {
        const { id } = params.row;
        if (selectedRowIds.includes(id)) {
            setSelectedRowIds(prevSelectedRowIds =>
                prevSelectedRowIds.filter(rowId => rowId !== id)
            );
        } else {
            setSelectedRowIds(prevSelectedRowIds => [...prevSelectedRowIds, id]);
        }
    };

    const handleClassChange = (event) => {
        setSelectedClass(event.target.value); // Update selected class filter
    };

    // Filter data based on selected class
    const filteredData = selectedClass ? modifiedData.filter(student => student.City === selectedClass) : modifiedData;

    return (
        <>
            <div className="content">

                <div className="" style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <div style={{display:'flex', gap:"10px"}}>
                <Button style={{ background: 'unset', color: 'rgba(18, 113, 215, 1)' }}>
                       Select Class
                    </Button>
                    <Button style={{ background: 'unset', color: 'rgba(18, 113, 215, 1)' }}>
                       Select Marks
                    </Button>
                    <Button style={{ background: 'unset', color: 'rgba(18, 113, 215, 1)' }}>
                       Select Age
                    </Button>
                    </div>

                    <Button style={{ background: 'rgba(18, 113, 215, 1)', color: 'white' }}>
                        <Link to='/admin/AddStudent'> Add Students</Link>
                    </Button>
                </div>
                {/* Select input for class filter */}
               
                <DataGrid
                    columns={columns}
                    rows={filteredData}
                    disableColumnFilter
                    disableDensitySelector
                    slots={{ toolbar: GridToolbar }}
                    selectionModel={selectedRowIds}
                    onRowClick={handleRowClick}
                />
            </div>
        </>
    );
}

export default Students;
