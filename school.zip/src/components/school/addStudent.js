import React, { useState, useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Button } from 'reactstrap'
//API Methods
import { GetApprovedSchoolService } from "service/getApproveSchoolService";
import { Spinner } from 'reactstrap';
import {
    FormControl,
    FormErrorMessage,
} from '@chakra-ui/react'


import { AddStudentService } from 'service/addStudentService'
import { Select } from '@mui/material';
import { useNavigate } from 'react-router-dom';
function AddStudent() {
    const school = useSelector((state) => state?.getApprovedSchoolSlice?.admin)
    const loading = useSelector((state) => state?.addStudentSlice?.loading)

    const dispatch = useDispatch()



    const [student, setStudent] = useState({
        fname: "",
        fprofession: "",
        fincome: '',
        fadhar: "",
        fpancard: '',
        mothername: "",
        mprofession: "",
        mincome: "",
        madhar: '',
        mpancard: "",
        numofChild: "",
        candidatename: "",
        grade: "",
        dob: "",
        currentSchool: "",
        residentaladdress: '',
        contactnumber: '',
        stuemail: "",
        Marks: "",
        password: "",
        term: "",
        gradeFieldToSetGrade:"",
        amount :""
    })
    const [file, setFile] = useState({
        fadharfile: "",
        fatherpanfile: "",
        motheradharcardfile: "",
        motherpanfile: "",
        reciept: "",
        idPrrofImage:""
    })

    const [errors, setErrors] = useState({
        term: "",
        reciept: ""
    });

    const validateForm = () => {
        const errors = {};
        if (!student.term) {
            errors.term = 'Semester  is required';
        }
        if (!file.reciept) {
            errors.reciept = 'Student Reciept  is required';
        }


        return errors;
    };
    const [inputValue, setInputValue] = useState('');
    const [suggestions, setSuggestions] = useState([]);
    const [selectedSchool, setselectedschool] = useState();

    const handleChange = (e) => {
        const { name, value } = e.target;

        setStudent({
            ...student,
            [name]: value
        });
    }
    const handleSchoolchange = (e) => {
        const { name, value } = e.target;
        setInputValue(value)

        if (value === '') {
            // Clear suggestions if input value is empty
            setSuggestions([]);
        } else {
            // Filter suggestions based on the input value
            const filteredSchools = school?.filter(item => item.schoolName.toLowerCase().includes(value.toLowerCase()));
            setSuggestions(filteredSchools);
        }
    }
    const handleSelectSchool = (selectedSchool) => {
        // Update the input value with the selected school name
        setselectedschool(selectedSchool)
        setInputValue(selectedSchool.schoolName);
        setSuggestions([]);

    };

    const handleFile = (event) => {
        const { name, files } = event.target;
        setFile(prevState => ({
            ...prevState,
            [name]: files[0] // or simply files if you want to store the entire array
        }));
    }
    const navigate = useNavigate()

    const handleClcik = async (e) => {
        e.preventDefault();
        try {
            const errors = validateForm();
            setErrors(errors);
            if (Object.keys(errors).length === 0) {
                const data = {
                    file, student, selectedSchool
                }
                await dispatch(AddStudentService(data)).unwrap()
                navigate('/admin/pending')

            } else {
                console.log('Form has errors:', errors);
            }
        } catch (error) {
            console.error('Error while handling form submission:', error);
        }
    }

    useEffect(() => {
        dispatch(GetApprovedSchoolService())
    }, [dispatch])
    return (
        <>
            <style>
                {
                    `
                    select {
                        padding: 10px;
                        background: white;
                        margin-right: 7px;
                        width:100%;
                    }
                    `
                }
            </style>

            <div className="content">
                {/* <!-- Main Content --> */}
                <div class="col-xs-12 col-lg-12 col-sm-12 col-md-12 mt-4" >
                    <h4>Candidate Information</h4>
                    <div class="row">
                        <div class="col-lg-6 col-xs-12 col-sm-6">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Student Name/ छात्र का नाम</label>
                                <input
                                    value={student?.candidatename}
                                    onChange={handleChange}
                                    name="candidatename"
                                    type="text"
                                    class="form-control"
                                    id="exampleInputEmail1"
                                    placeholder="Candidate Name"

                                />

                            </div>
                        </div>

                        <div class="col-lg-offset-0 col-lg-6 col-xs-12 col-sm-6">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Class/ कक्षा</label>
                                <input
                                    value={student?.grade}
                                    onChange={handleChange}
                                    name='grade'
                                    type="text"
                                    class="form-control"
                                    id="exampleInputEmail1"
                                    placeholder="class"
                                />
                            </div>
                        </div>
                        <div class="col-lg-offset-0 col-lg-6 col-xs-12 col-sm-6">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Date of Birth /जन्म की तारीख</label>
                                <input
                                    name="dob"
                                    value={student?.dob}
                                    onChange={handleChange}
                                    type="date"
                                    class="form-control"
                                    id="exampleInputEmail1"

                                />
                            </div>
                        </div>
                        <style>
                            {
                                `
        div#suggestions {
            margin-top:9px;
            padding: 2px;
                box-shadow: rgba(100, 100, 111, 0.2) 0px 7px 29px 0px !important;
        }
        div#suggestions p:hover{
           cursor:pointer;
           background:rgb(18, 113, 215);
           color:white;
        }
        div#suggestions p{
            margin-bottom:5px;

        }

        `
                            }
                        </style>

                        <div class="col-lg-offset-0 col-lg-6 col-xs-12 col-sm-12">
                            <label for="Gender" class="select">Current School /वर्तमान विद्यालय </label>
                            {/* <div class="form-group">
                                <select name="currentSchool"
                                    onChange={handleChange}

                                >
                                    <option >Select School</option>

                                    {
                                        Array.isArray(school) && school?.map((item) => {
                                            return (
                                                <>
                                                    <option value={JSON.stringify({ schoolId: item.schoolId, schoolName: item.schoolName })}>
                                                        {item.schoolName}
                                                    </option>                                                </>
                                            )
                                        })
                                    }
                                </select>


                            </div> */}
                            <div className="form-group">
                                <input
                                    placeholder="Type to search school"
                                    name="currentSchool"
                                    onChange={handleSchoolchange}
                                    value={inputValue}

                                    type="text"
                                    class="form-control"
                                    id="exampleInputEmail1"
                                />
                                <div id="suggestions">
                                    {suggestions.map((item, index) => (
                                        <div
                                            key={index}
                                            className="suggestion-item"
                                            onClick={() => handleSelectSchool(item)}
                                        >
                                            <p>    {item.schoolName}</p>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-offset-0 col-lg-6 col-xs-12 col-sm-12">
                            <div class="form-group">
                                <label for="Gender" class="select">Residential / Addressआवासीय पता</label>
                                <input

                                    name="residentaladdress"
                                    value={student?.residentaladdress}
                                    onChange={handleChange}
                                    type=""
                                    class="form-control"
                                    id="exampleInputEmail1"
                                    placeholder="Residential Address"

                                />


                            </div>
                        </div>
                        <div class="col-lg-offset-0 col-lg-6 col-xs-12 col-sm-12">
                            <div class="form-group">
                                <label for="Gender" class="select">Contact Number / संपर्क संख्या</label>
                                <input
                                    name="contactnumber"
                                    value={student?.contactnumber}
                                    onChange={handleChange}
                                    type="text"
                                    class="form-control"
                                    id="exampleInputEmail1"
                                    placeholder="Contact Number"

                                />

                            </div>
                        </div>

                        <div class="col-lg-offset-0 col-lg-6 col-xs-6">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Email Address / मेल पता</label>
                                <input
                                    name="stuemail"
                                    value={student?.stuemail}
                                    onChange={handleChange}
                                    type="email"
                                    class="form-control"
                                    id="exampleInputEmail1"
                                    placeholder="Email Address"
                                />
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Marks / अंक</label>
                                <input
                                    name="Marks"
                                    value={student?.Marks}
                                    onChange={handleChange}
                                    type="text"
                                    class="form-control"
                                    id="exampleInputEmail1"
                                    placeholder="marks"
                                />
                            </div>
                        </div>
                        <div class="col-lg-offset-0 col-lg-6 col-xs-6">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Password / पासवर्ड</label>
                                <input
                                    name="password"
                                    value={student?.password}
                                    onChange={handleChange}
                                    type="text"
                                    class="form-control"
                                    id="exampleInputEmail1"
                                    placeholder="Password"
                                />

                            </div>
                            <div class="col-lg-offset-0 col-lg-12 col-xs-12">
                                <label for="exampleInputEmail1">Select semester / सेमेस्टर चुनें.</label>

                                <div class="form-group">
                                    <FormControl
                                        isInvalid={!!errors?.term}>
                                        <select name="term"
                                            onChange={handleChange}
                                        >
                                            <option value="1 semester">1 semester</option>
                                            <option value="2 semester">2 semester</option>
                                            <option value="3 semester">3 semester</option>
                                            <option value="4 semester">4 semester</option>
                                            <option value="5 semester">5 semester</option>
                                            <option value="6 semester">6 semester</option>
                                            <option value="Monthly ">Monthly </option>
                                            <option value="Annually">Annually</option>



                                        </select>
                                        <FormErrorMessage style={{ color: 'red' }}>{errors.term}</FormErrorMessage>

                                    </FormControl>

                                </div>

                            </div>
                            

                        </div>
                        <div class="col-lg-offset-0 col-lg-6 col-xs-12 col-sm-3">
                                <div class="form-group">
                                    <label for="Gender" class="select" style={{ width: '100%' }}>Student Reciept/छात्र रसीद</label>
                                    <FormControl isInvalid={!!errors?.reciept}>
                                        <input
                                            onChange={handleFile}
                                            name="reciept"
                                            type="file"
                                            class="form-control"
                                            id="exampleInputEmail1"
                                            placeholder="FILE"
                                        />
                                        <FormErrorMessage style={{ color: "red" }}>{errors.reciept}</FormErrorMessage>

                                    </FormControl>

                                </div>
                            </div>
                        <div class="col-lg-offset-0 col-lg-6 col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label for="Gender" class="select" style={{ width: '100%' }}>Amount/मात्रा</label>
                                    <input
                                        onChange={handleChange}
                                        name="amount"
                                        type="number"
                                        class="form-control"
                                        id="exampleInputEmail1"
                                        placeholder="Amount"
                                    />


                            </div>
                        </div>
                        <div class="col-lg-offset-0 col-lg-6 col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label for="Gender" class="select" style={{ width: '100%' }}>Grade/श्रेणी
</label>
                                    <input
                                        onChange={handleChange}
                                        name="gradeFieldToSetGrade"
                                        type="text"
                                        class="form-control"
                                        id="exampleInputEmail1"
                                        placeholder="Grade"
                                    />


                            </div>
                        </div>
                        <div class="col-lg-offset-0 col-lg-6 col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label for="Gender" class="select" style={{ width: '100%' }}>Student Id Proof/छात्र आईडी प्रमाण
</label>
                               
                                    <input
                                        onChange={handleFile}
                                        name="idPrrofImage"
                                        type="file"
                                        class="form-control"
                                        id="exampleInputEmail1"
                                        placeholder="FILE"
                                    />


                            </div>
                        </div>



                    </div>
                    <hr />

                    <h4>Family Information</h4>
                    <div class="row">
                        <div class="col-lg-6 col-xs-12 col-sm-4">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Father's Name / पिता का नाम</label>
                                <input
                                    value={student?.fname}
                                    onChange={handleChange}
                                    name="fname"
                                    type=""
                                    class="form-control"
                                    id="exampleInputEmail1"
                                    placeholder="Father's Name"

                                />

                            </div>
                        </div>

                        <div class="col-lg-offset-0 col-lg-3 col-xs-12 col-sm-4">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Father's Profession / पिता का व्यवसाय</label>
                                <input
                                    value={student?.fprofession}
                                    onChange={handleChange}
                                    name="fprofession"
                                    type="text"
                                    class="form-control"
                                    id="exampleInputEmail1"
                                    placeholder="Father's Profession"

                                />

                            </div>
                        </div>

                        <div class="col-lg-offset-0 col-lg-3 col-xs-12 col-sm-4">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Father's Income / पिता की आय</label>
                                <input
                                    value={student?.fincome}
                                    onChange={handleChange}
                                    name="fincome"
                                    type=""
                                    class="form-control"
                                    id="exampleInputEmail1"
                                    placeholder='Father income'

                                />

                            </div>
                        </div>



                        <div class="col-lg-offset-0 col-lg-3 col-xs-3 col-sm-3">
                            <div class="form-group">
                                <label for="Gender" class="select">Aadhaar Card No. / आधार कार्ड नं. </label>
                                <input
                                    name="fadhar"
                                    value={student?.fadhar}
                                    onChange={handleChange}
                                    type="text"
                                    class="form-control"
                                    id="exampleInputEmail1"
                                    placeholder="Aadhaar Card No."

                                />

                            </div>
                        </div>
                        <div class="col-lg-offset-0 col-lg-3 col-xs-3 col-sm-3">
                            <div class="form-group">
                                <label for="Gender" class="select"></label>
                                <input
                                    onChange={handleFile}
                                    name="fadharfile"
                                    type="file"
                                    class="form-control"
                                    id="exampleInputEmail1"
                                    placeholder="FILE"

                                />


                            </div>
                        </div>
                        <div class="col-lg-offset-0 col-lg-3 col-xs-3 col-sm-3">
                            <div class="form-group">
                                <label for="Gender" class="select">PAN Card No. / पैन कार्ड नं.</label>
                                <input
                                    name="fpancard"
                                    value={student?.fpancard}
                                    onChange={handleChange}
                                    type="text"
                                    class="form-control"
                                    id="exampleInputEmail1"
                                    placeholder="PAN Card No."
                                />
                            </div>
                        </div>
                        <div class="col-lg-offset-0 col-lg-3 col-xs-3">
                            <div class="form-group">
                                <label for="exampleInputEmail1"></label>
                                <input
                                    onChange={handleFile}
                                    name="fatherpanfile"
                                    type="file"
                                    class="form-control"
                                    id="exampleInputEmail1"
                                    placeholder="Email Address"
                                />
                            </div>
                        </div>

                        <div class="col-lg-6 col-xs-12 col-sm-4">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Mother's Name / माँ का नाम</label>
                                <input
                                    name="mothername"
                                    value={student?.mothername}
                                    onChange={handleChange}
                                    type="text"
                                    class="form-control"
                                    id="exampleInputEmail1"
                                    placeholder="Mother's Name"
                                />

                            </div>
                        </div>

                        <div class="col-lg-offset-0 col-lg-3 col-xs-12 col-sm-4">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Mother's Profession / माँ का पेशा</label>
                                <input
                                    name="mprofession"
                                    value={student?.mprofession}
                                    onChange={handleChange}
                                    type="text"
                                    class="form-control"
                                    id="exampleInputEmail1"
                                    placeholder="Mother's Profession"

                                />

                            </div>
                        </div>

                        <div class="col-lg-offset-0 col-lg-3 col-xs-12 col-sm-4">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Mother's Income / माँ की आय</label>
                                <input
                                    name="mincome"
                                    value={student?.mincome}
                                    onChange={handleChange}
                                    type=""
                                    class="form-control"
                                    id="exampleInputEmail1"
                                    placeholder='Mother Income'

                                />

                            </div>
                        </div>


                        <div class="col-lg-offset-0 col-lg-3 col-xs-3 col-sm-3">
                            <div class="form-group">
                                <label for="Gender" class="select">Aadhaar Card No / आधार कार्ड नं. </label>
                                <input
                                    name="madhar"
                                    value={student?.madhar}
                                    onChange={handleChange}
                                    type="text"
                                    class="form-control"
                                    id="exampleInputEmail1"
                                    placeholder="Aadhaar Card No."

                                />

                            </div>
                        </div>
                        <div class="col-lg-offset-0 col-lg-3 col-xs-3 col-sm-3">
                            <div class="form-group">
                                <label for="Gender" class="select"></label>
                                <input
                                    name="motheradharcardfile"
                                    onChange={handleFile}
                                    type="file"
                                    class="form-control"
                                    id="exampleInputEmail1"
                                    placeholder="FILE"

                                />


                            </div>
                        </div>
                        <div class="col-lg-offset-0 col-lg-3 col-xs-3 col-sm-3">
                            <div class="form-group">
                                <label for="Gender" class="select">PAN Card No./ पैन कार्ड नं.</label>
                                <input
                                    name="mpancard"
                                    value={student.mpancard}
                                    onChange={handleChange}
                                    type="text"
                                    class="form-control"
                                    id="exampleInputEmail1"
                                    placeholder="PAN Card No."

                                />

                            </div>
                        </div>

                        <div class="col-lg-offset-0 col-lg-3 col-xs-3">
                            <div class="form-group">
                                <label for="exampleInputEmail1"></label>
                                <input
                                    name="motherpanfile"
                                    onChange={handleFile}

                                    type="file"
                                    class="form-control"
                                    id="exampleInputEmail1"
                                    placeholder="Email Address"

                                />

                            </div>
                        </div>

                        <div class="col-lg-offset-0 col-lg-6     col-xs-3">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Number of Children in the Family / परिवार में बच्चों की संख्या</label>
                                <input
                                    value={student?.numofChild}
                                    onChange={handleChange}
                                    name='numofChild'
                                    type="number"
                                    class="form-control"
                                    id="exampleInputEmail1"
                                    placeholder="Number of Children in the Family"

                                />

                            </div>
                        </div>
                    </div>



                    {/* <div class="modal fade" id="exitApplication" tabindex="-1" role="dialog" aria-labelledby="exitApplication">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                        <h4 class="modal-title" id="myModalLabel">Before you exit</h4>
                                    </div>
                                    <div class="modal-body">
                                        Do you want to save this application for later?
                                    </div>
                                    <div class="modal-footer">
                                        <a href="vcp.html" role="button" class="btn btn-default btn-large">Don't save</a>
                                        <a href="vcp.html" role="button" class="btn btn-success btn-large">Save</a>
                                    </div>
                                </div>
                            </div>
                        </div> */}
                    {/* <!-- /Exit (Are you sure?) Modal --> */}
                    <div class="pull-right">
                        <Button role="button" type='submit' class="btn btn-primary btn-large" style={{ background: 'rgb(18, 113, 215)', color: 'white', marginTop: '30px' }} onClick={handleClcik}>
                            {
                                loading ? (
                                    <>
                                        <Spinner
                                            thickness='10px'
                                            speed='0.65s'
                                            emptyColor='blue'
                                            color='blue.500'
                                            size='sm'
                                        />
                                    </>
                                ) : 'Submit'
                            }
                        </Button>
                    </div>
                </div>
                {/* <!-- /Main Content -- */}
            </div>
        </>
    )
}
export default AddStudent
