import React, { useState } from "react";
import { NavLink, useLocation, useNavigate } from "react-router-dom";
import { Nav } from "reactstrap";
import PerfectScrollbar from "perfect-scrollbar";
import logo from '../../assets/img/adlogo.png'
import { Button } from "react-bootstrap";
import { sucessToast } from "toast/toast";
var ps;

function Sidebar(props) {
  const location = useLocation();
  const sidebar = React.useRef();

  const activeRoute = (routeName) => {
    return location.pathname.indexOf(routeName) > -1 ? "active" : "";
  };

  const [activeSubMenu, setActiveSubMenu] = useState(null);

  const toggleSubMenu = (index) => {
    if (activeSubMenu === index) {
      setActiveSubMenu(null);
    } else {
      setActiveSubMenu(index);
    }
  };

  React.useEffect(() => {
    if (navigator.platform.indexOf("Win") > -1) {
      ps = new PerfectScrollbar(sidebar.current, {
        suppressScrollX: true,
        suppressScrollY: false,
      });
    }
    return function cleanup() {
      if (navigator.platform.indexOf("Win") > -1) {
        ps.destroy();
      }
    };
  });
  const navigate=useNavigate()
   const handleclick=()=>{
    localStorage.clear('')
    navigate('/login')
    sucessToast('Logout Successfull')
   }

  return (
    <>
    <style>
      {
        `
        button.btn.btn-primary {
          background: #909261 !important;
          color: white !important;
      }
        `
      }
    </style>
    <div
      className="sidebar"
      data-color={props.bgColor}
      data-active-color={props.activeColor}
    >
      <div className="logo">
        <a href="" className="simple-text logo-mini">
          {/* <div className="logo-img">
            <img src={logo} alt="react-logo" />
          </div> */}
        </a>
        <a href="" className="simple-text logo-normal">
        <img src={logo}/>
        </a>
      </div>
      <div className="sidebar-wrapper" ref={sidebar}>
        <Nav>
          {props.routes.map((prop, key) => (
            <li
              className={activeRoute(prop.layout + prop.path) + (prop.pro ? " active-pro" : "")}
              key={key}
            >
              {prop.submenu ? (
                <a href="#!" onClick={() => toggleSubMenu(key)}>
                  <i className={prop.icon} />
                  <p>{prop.name}</p>
                </a>
              ) : (
                <NavLink to={prop.layout + prop.path} className="nav-NavLink">
                  <i className={prop.icon} />
                  <p>{prop.name}</p>
                </NavLink>
              )}
              {prop.submenu && activeSubMenu === key && (
                <ul className="submenu">
                  {prop.submenu.map((subprop, subkey) => (
                    <li
                      className={activeRoute(prop.layout + subprop.path)}
                      key={subkey}
                    >
                      <NavLink to={prop.layout + subprop.path} className="nav-NavLink">
                        <p>{subprop.name}</p>
                      </NavLink>
                    </li>
                  ))}
                </ul>
              )}
            </li>
          ))}
           
        </Nav>
        <div style={{width:'100%',display:'flex',alignItems:'center',justifyContent:'flex-start',position:'relative',left:'10px'}}>
      <i  class="fa-solid fa-right-from-bracket" style={{position:'relative',color:'white',bottom:'14px',left:'14px'}}></i>

      <Button  onClick={handleclick} style={{background:'unset',color:'white',fontSize:'17px',marginBottom:'40px'}}>
        Logout</Button>
      </div>
      </div>
    </div>
    </>
    
  );
}

export default Sidebar;
