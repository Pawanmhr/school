import React, { useEffect } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import AdminLayout from 'layouts/Admin.js';
import Login from 'pages/auth/login';
import { isAuthenticated } from './utils/CheckRoute';
import { useNavigate } from 'react-router-dom';
import Pending from 'components/school/pending';
import AddSchool from 'pages/auth/signup';
import { ChakraProvider } from '@chakra-ui/react';
import PdfModal from 'components/school/pdfModal';
function App() {
    const navigate = useNavigate();

    useEffect(() => {
        // Check for authentication when the component mounts
        if (!isAuthenticated()) {
            // If the user is not authenticated, navigate to the login or signup page
            if (window.location.pathname === '/signup') {
                // If the user is on the signup page, navigate to the signup page
                navigate('/signup');
            } else {
                // Otherwise, navigate to the login page
                navigate('/login');
            }
        }
    }, []);

    return (
        <>
            <Routes>
                <Route path="/login" element={<Login />} />
              <Route path="/admin/pdfview" element={<ChakraProvider>  <PdfModal /> </ChakraProvider>} />

                <Route path="/signup" element={<ChakraProvider><AddSchool /></ChakraProvider>} />
                <Route path="/admin/*" element={isAuthenticated() ? <AdminLayout /> : <Navigate to="/login" replace />} />
                <Route path="/" element={isAuthenticated() ? <Navigate to="/admin/dashboard" replace /> : <Navigate to="/login" replace />} />
            </Routes>
        </>
    );
}

export default App;
