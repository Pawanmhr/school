import Dashboard from "pages/Dashboard.js";
import DeliveryAgent from "pages/DeliveryAgent/DeliveryAgent";
import BlogPost from "pages/blogs/BlogPost";
import Blogs from "pages/blogs/Blogs";
import UserPage from "pages/users/User";
import AddDeliveryAgent from "pages/DeliveryAgent/AddDeliveryAgent";
import UpdateDeliveryAgent from "pages/DeliveryAgent/UpdateDeliveryAgent";
import ViewCategory from "pages/product_category/category/ViewCategory";
import AddNewCategory from "pages/product_category/category/AddNewCategory";
import UpdateCategory from "pages/product_category/category/UpdateCategory";
import SubCategory from "pages/product_category/sub_category/SubCategory"
import AddNewSubCategory from "pages/product_category/sub_category/AddNewSubCategory";
import UpdateSubCategory from "pages/product_category/sub_category/UpdateSubCategory";
import SuperCategory from "pages/product_category/super_category/SuperCategory";
import AddNewSuperCategory from "pages/product_category/super_category/addSuperCategory";
import UpdateSuperCategory from "pages/product_category/super_category/updateSuperCategory";
import Products from "pages/addAndUpdateProduct/Products";
import AddProduct from "pages/addAndUpdateProduct/addProduct";
import UpdateProduct from "pages/addAndUpdateProduct/updateProduct";
import OtherImages from "pages/all_Others/otherImages";
import Pending from "components/school/pending";

var routes = [
  //Dashboard route
  
  {
    path: "/dashboard",
    name: "Dashboard",
    icon: "nc-icon nc-bank",
    component: <Dashboard />,
    layout: "/admin",
    showInSidebar: true,
  },
  // End of dashboard route
  // User Route
  {
    path: "/user-page",
    name: "Users",
    icon: "fas fa-users",
    component: <UserPage />,
    layout: "/admin",
    showInSidebar: true,
  },
  //End of User Route
  //Delivery Agent 
  {
    path: "/delivery-agents",
    name: "Delivery Agents",
    icon: "fas fa-user-tie",
    component: <DeliveryAgent />,
    layout: "/admin",
    showInSidebar: true,
  },


  {
    path: "/pending",
    name: "pending",
    icon: "fas fa-user-tie",
    component: <Pending />,
    layout: "/admin",
    showInSidebar: true,
  },

  {
    path: "/add-new-agent",
    name: "Delivery Agent",
    icon: "nc-icon nc-caps-small",
    component: <AddDeliveryAgent />,
    layout: "/admin",
    showInSidebar: false,
  },
  {
    path: "/update-new-agent",
    name: "Delivery Agent",
    icon: "nc-icon nc-caps-small",
    component: <UpdateDeliveryAgent />,
    layout: "/admin",
    showInSidebar: false,
  },
  // End of Delivery Agent
  // Product Category
  {
    path: "/view-category",
    name: "View Category",
    icon: "nc-icon nc-caps-small",
    component: <ViewCategory />,
    layout: "/admin",
    showInSidebar: false,
  },
  {
    path: "/add-new-category",
    name: "View Category",
    icon: "nc-icon nc-caps-small",
    component: <AddNewCategory />,
    layout: "/admin",
    showInSidebar: false,
  },
  {
    path: "/update-category",
    name: "View Category",
    icon: "nc-icon nc-caps-small",
    component: <UpdateCategory />,
    layout: "/admin",
    showInSidebar: false,
  },
  {
    path: "/sub-category",
    name: "View Sub Category",
    icon: "nc-icon nc-caps-small",
    component: <SubCategory />,
    layout: "/admin",
    showInSidebar: false,
  },
  {
    path: "/add-sub-category",
    name: "View Sub Category",
    icon: "nc-icon nc-caps-small",
    component: <AddNewSubCategory />,
    layout: "/admin",
    showInSidebar: false,
  },
  {
    path: "/update-sub-category",
    name: "View Sub Category",
    icon: "nc-icon nc-caps-small",
    component: <UpdateSubCategory />,
    layout: "/admin",
    showInSidebar: false,
  },
  {
    path: "/super-category",
    name: "View Super Category",
    icon: "nc-icon nc-caps-small",
    component: <SuperCategory />,
    layout: "/admin",
    showInSidebar: false,
  },
  {
    path: "/add-super-category",
    name: "View Super Category",
    icon: "nc-icon nc-caps-small",
    component: <AddNewSuperCategory />,
    layout: "/admin",
    showInSidebar: false,
  },
  {
    path: "/update-super-category",
    name: "View Super Category",
    icon: "nc-icon nc-caps-small",
    component: <UpdateSuperCategory />,
    layout: "/admin",
    showInSidebar: false,
  },
  {
    path: "/products",
    name: "Products Categories",
    icon: "fab fa-product-hunt",
    layout: "/admin",
    showInSidebar: true,
    submenu: [
      {
        path: "/view-category",
        name: "View Category",
        component: <ViewCategory />,
        layout: "/admin",
        showInSidebar: true,
      },

      {
        path: "/sub-category",
        name: "View Sub Category",
        component: <SubCategory />,
        layout: "/admin",
        showInSidebar: true,
      },

      {
        path: "/super-category",
        name: "View Super Category",
        component: <SuperCategory />,
        layout: "/admin",
        showInSidebar: true,
      },
    ],
  },
  // End of Product
  // Blog
  {
    path: "/add-blog",
    name: "Blogs",
    icon: "fas fa-blog",
    component: <BlogPost />,
    layout: "/admin",
    showInSidebar: false,

  },
  {
    path: "/blog",
    name: "Blogs",
    icon: "fas fa-blog",
    component: <Blogs />,
    layout: "/admin",
    showInSidebar: true,

  },
  // End of blog
  //Products
  {
    path: "/all-products",
    name: "View / Add Product",
    icon: "far fa-clipboard",
    component: <Products />,
    layout: "/admin",
    showInSidebar: true,
  },
  {
    path: "/add-products",
    name: "View / Add Product",
    icon: "far fa-clipboard",
    component: <AddProduct />,
    layout: "/admin",
    showInSidebar: false,
  },
  {
    path: "/update-products",
    name: "View / Add Product",
    icon: "far fa-clipboard",
    component: <UpdateProduct />,
    layout: "/admin",
    showInSidebar: false,
  },
  //End Of Products
  // Other Images 

  {
    path: "/all-others-images",
    name: "All Others",
    icon: "far fa-clipboard",
    component: <OtherImages />,
    layout: "/admin",
    showInSidebar: false,
  },

  {
    path: "/products",
    name: "All Others",
    icon: "fab fa-audible",
    layout: "/admin",
    showInSidebar: true,
    submenu: [
      {
        path: "/all-others-images",
        name: "All Others",
        showInSidebar: true,
      },
      {
        path: "/add-product",
        name: "Pages Details",
        showInSidebar: true,
      },
    ],
  },
  //End Of Others Images 
  {
    path: "/products",
    name: "Order Details",
    icon: "fab fa-accusoft",
    layout: "/admin",
    showInSidebar: true,
    submenu: [
      {
        path: "/all-products",
        name: "View Order",
        showInSidebar: true,
        component: <UserPage />,
      },
      {
        path: "/add-product",
        name: "Cancel Order",
        showInSidebar: true,
      },
      {
        path: "/add-product",
        name: "Hold Order",
        showInSidebar: true,
      },
      {
        path: "/add-product",
        name: "Order Reciepts",
        showInSidebar: true,
      },
      {
        path: "/add-product",
        name: "Close Order",
        showInSidebar: true,
      },
    ],
  },
  {
    path: "/products",
    name: "Inventry",
    icon: "fas fa-shopping-basket",
    layout: "/admin",
    showInSidebar: true,
    submenu: [
      {
        path: "/all-products",
        name: "Vender",
        showInSidebar: true,
      },
      {
        path: "/add-product",
        name: "Chennel Partner",
        showInSidebar: true,
      },
      {
        path: "/add-product",
        name: "Available Inventry",
        showInSidebar: true,
      },
      {
        path: "/add-product",
        name: "Total Inventry",
        showInSidebar: true,
      },
      {
        path: "/add-product",
        name: "Comming Inventry",
        showInSidebar: true,
      },
    ],
  },
  {
    path: "/products",
    name: "City",
    icon: "fas fa-city",
    layout: "/admin",
    showInSidebar: true,
    submenu: [
      {
        path: "/all-products",
        name: "City",
        showInSidebar: true,
      },
      {
        path: "/add-product",
        name: "PinCode",
        showInSidebar: true,
      },
    ],
  },
  {
    path: "/products",
    name: "Reminder",
    icon: "fas fa-mail-bulk",
    layout: "/admin",
    showInSidebar: true,
    submenu: [
      {
        path: "/reminder-order",
        name: "Reminder Order",
        showInSidebar: true,
        component: <UserPage />, // Use the ReminderOrder component here
      },
      {
        path: "/collection-emi",
        name: "Collection EMI",
        showInSidebar: true,
        component: <Dashboard />, // Use the CollectionEMI component here
      },
    ],
  },

];
export default routes;
