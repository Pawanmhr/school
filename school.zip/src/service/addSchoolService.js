import { createAsyncThunk } from "@reduxjs/toolkit";
import axios from 'axios';
import { BASE_URL } from "../auth/baseUrl";
import { handleError } from "../utils/handleError";
import { basicAuth } from "../auth/basicauth"; // Import basicAuth from the appropriate location


export const AddSchoolService = createAsyncThunk(
  "AddSchoolService",
  async (payload) => {
    try {
      const schoolId=localStorage.getItem('schoolId')

      const formdata=new FormData()
      const Pay=payload?.school
      const data={
        "schoolDetails": {
            "name": Pay?.name,
            "email": Pay?.email,
            "password": Pay.password,
            "phoneNumber": Pay?.number,
            "alternativePhoneNumber": Pay?.landline
        },
        "schoolAddressDetails": {
            "addressType": Pay?.address,
            "street": null,
            "city": Pay?.city,
            "state": Pay?.state,
            "pinCode": Pay?.pincode,
            "country": "USA",
            "buildingNumber": "Building 1",
            "floorName": "1st Floor",
            "buildingName": "Sunrise Apartments"
        },
        "passSubAdminsId": null,
        "websiteUrl": Pay?.website
    }
    formdata.append('data',JSON.stringify(data))
    payload?.file?.forEach((fileObject) => {
        
      const file = fileObject.file;
      console.log(file)
      formdata.append('documentFile', file); // Append each File object itself
    });


      let url = BASE_URL + 'createSchool';
      const config = {
        headers: {
          "Authorization": basicAuth, // Include basic authentication header
        }
      };
      const res = await axios.post(url, formdata, config); // Pass the config object as the third parameter
      console.log(res)
      return res.data;
    } catch (error) {
      console.log(error)
      handleError(error); // Pass the entire error object to the handleError function

      throw error;
    }
  }
);
