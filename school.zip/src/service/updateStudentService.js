import { createAsyncThunk } from "@reduxjs/toolkit";
import axios from 'axios';
import { BASE_URL } from "../auth/baseUrl";
import { handleError } from "../utils/handleError";
import { basicAuth } from "../auth/basicauth"; // Import basicAuth from the appropriate location


export const UpdateStudentService = createAsyncThunk(
  "UpdateStudentService",
  async (payload) => {
    const formData=new FormData()
    try {
    console.log(payload,'papapap')

      const stu=payload?.student
    const parsedValue = stu?.currentSchool;

      const data={
        "studentDetails": {
            "name": stu?.candidatename,
            "phoneNumber": stu?.contactnumber,
            "alternativePhoneNumber": "+9876543210"
        },
        "residentialAddress": {
            "street": null,
            "city": null,
            "state": stu?.residentaladdress,
            "pinCode": null,
            "country": null,
            "buildingNumber": "Building 1",
            "floorName": "1st Floor",
            "buildingName": "Sunrise Apartments"
        },
        "gradeFieldToSetGrade":stu?.gradeFieldToSetGrade,
        "amount":stu?.amount,
        "terms": stu?.term,
        "grade": stu?.grade,
        "marks": stu?.Marks,
        "remark": "Excellent student",
        "dateOfBirth": stu?.dob,
        "currentSchool": stu?.currentSchool,
        "fatherName": stu?.fname,
        "fatherProfession": stu?.fprofession,
        "fatherIncome": stu?.fincome,
        "motherName": stu?.mothername,
        "motherProfession":stu?.mprofession,
        "motherIncome": stu?.mincome,
        "numberOfChildren": stu?.numofChild,
        "aadhaarCardNumber1": stu?.fadhar,
        "panCardNumber1": stu?.fpancard,
        "aadhaarCardNumber2":   stu?.madhar,
        "panCardNumber2": stu?.mpancard,
        "passSchoolId": {
          "schoolId":null
        },
    }
      
    formData.append('updateData',JSON.stringify(data))
     formData.append('aadhaarCardImage1',payload.file?.fadharfile)
     formData.append('aadhaarCardImage2',payload.file?.motheradharcardfile)
     formData.append('panCardImage1',payload.file?.fatherpanfile)
     formData.append('panCardImage2',payload.file?.motherpanfile)
     formData.append('updateStudentReceipt',payload.file?.reciept)
     formData.append('updateIdProofImage', payload.file?.idPrrofImage)

     
    let url = BASE_URL + `updateStudentById/${payload?.id}`;
      const config = {
        headers: {
          "Authorization": basicAuth, // Include basic authentication header
        }
      };
      const res = await axios.put(url, formData, config); // Pass the config object as the third parameter
      console.log(res)
      return res.data;
    } catch (error) {
      console.log(error)
      handleError(error); // Pass the entire error object to the handleError function

      throw error;
    }
  }
);
// const data={
//   "studentDetails": {
//       "name": stu.candidatename,
//       "email": stu?.stuemail,
//       "password": "password123",
//       "phoneNumber": stu?.contactnumber,
//       "alternativePhoneNumber": "+9876543210"
//   },
//   "residentialAddress": {
//       "addressType": stu?.residentaladdress,
//       "street": "",
//       "city": "Anytown",
//       "state": "California",
//       "pinCode": "12345",
//       "country": "USA",
//       "buildingNumber": "Building 1",
//       "floorName": "1st Floor",
//       "buildingName": "Sunrise Apartments"
//   },
//   "terms": stu?.term,
//   "grade": stu?.grade,
//   "marks": stu?.Marks,
//   "remark": "Excellent student",
//   "dateOfBirth": stu?.dob,
//   "currentSchool": stu?.currentSchool,
//   "fatherName": stu?.fname,
//   "fatherProfession": stu?.fprofession,
//   "fatherIncome": stu?.fincome,
//   "motherName": stu?.mothername,
//   "motherProfession": stu?.mprofession,
//   "motherIncome": stu?.mincome,
//   "numberOfChildren": stu?.numofChild,
//   "passSchoolId": {
//       "schoolId": stu?.currentSchool
//   },
  
// }